﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ejer1obl
{
    public class Cuenta {

        private String titular;
        private double cantidad;
        
        public Cuenta(String titular)
        {
            this.titular = titular;
            this.cantidad = 0;
        }
        public Cuenta(String titular, double cantidad)
        {
            this.titular = titular;
            this.cantidad = cantidad;
        }

        public void Ingresar(double cantidad)
        {
            if (cantidad > 0)
            {
                this.cantidad += cantidad;
            }
        }

        public void Retirar(double cantidad)
        {
            if (this.cantidad - cantidad < 0)
            {
                this.cantidad = 0;
            }
            else
            {
                this.cantidad -= cantidad;
            }
        }

        public void Mostrar()
        {
            Console.WriteLine($"El/La titular es: {titular}");
            Console.WriteLine($"La cantidad es: {cantidad}");
        }
    }
    class Program
    {
        static void Main(String[] args)
        {
            Cuenta cuenta_1 = new Cuenta("Valentina Nieva");
            Cuenta cuenta_2 = new Cuenta("Milagros Nieva");

            cuenta_1.Ingresar(500);
            cuenta_2.Ingresar(150);

            cuenta_1.Retirar(200);
            cuenta_2.Retirar(500);

            cuenta_1.Mostrar();
            cuenta_2.Mostrar();

            Console.ReadLine();
        }
    }
}






    