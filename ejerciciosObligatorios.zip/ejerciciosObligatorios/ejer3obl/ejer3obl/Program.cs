﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Password
{
    // Atributos de la clase
    private const int LONG_DEF = 8;
    private int longitud;
    private string contraseña;

    // Propiedades para obtener y establecer longitud y contraseña
    public int Longitud
    {
        get { return longitud; }
        set { longitud = value; }
    }

    public string Contraseña
    {
        get { return contraseña; }
    }

    // Constructor por defecto, con longitud de 8
    public Password()
    {
        longitud = LONG_DEF;
        contraseña = GenerarContra();
    }

    // Constructor que establece la longitud ingresada y genera la contraseña
    public Password(int longitud)
    {
        this.longitud = longitud;
        contraseña = GenerarContra();
    }

    // Método para generar una contraseña aleatoria
    public string GenerarContra()
    {
        Random rand = new Random();
        string contraGenerada = "";

        for (int i = 0; i < longitud; i++)
        {
            int tipoCaracter = rand.Next(1, 4);

            if (tipoCaracter == 1) // Minúscula
            {
                char minuscula = (char)rand.Next(97, 123); // ASCII a-z
                contraGenerada += minuscula;
            }
            else if (tipoCaracter == 2) // Mayúscula
            {
                char mayuscula = (char)rand.Next(65, 91); // ASCII A-Z
                contraGenerada += mayuscula;
            }
            else // Número
            {
                char numero = (char)rand.Next(48, 58); // ASCII 0-9
                contraGenerada += numero;
            }
        }

        return contraGenerada;
    }

    // Método para verificar si la contraseña es fuerte
    public bool Fuerte()
    {
        int cuentaNumeros = 0;
        int cuentaMinusculas = 0;
        int cuentaMayusculas = 0;

        foreach (char c in contraseña)
        {
            if (c >= 'a' && c <= 'z')
                cuentaMinusculas++;
            else if (c >= 'A' && c <= 'Z')
                cuentaMayusculas++;
            else if (c >= '0' && c <= '9')
                cuentaNumeros++;
        }

        return cuentaNumeros >= 5 && cuentaMinusculas >= 1 && cuentaMayusculas >= 2;
    }
}

class Program
{
    static void Main()
    {
        Console.Write("Ingrese la cantidad de contraseñas a generar: ");
        int cantidad = int.Parse(Console.ReadLine());

        Console.Write("Ingrese la longitud de las contraseñas: ");
        int longitud = int.Parse(Console.ReadLine());

        Password[] passwords = new Password[cantidad];
        bool[] FuerteArray = new bool[cantidad];

        for (int i = 0; i < cantidad; i++)
        {
            passwords[i] = new Password(longitud);
            FuerteArray[i] = passwords[i].Fuerte();
        }

        Console.WriteLine("\nResultados:");
        for (int i = 0; i < cantidad; i++)
        {
            Console.WriteLine($"{passwords[i].Contraseña} - Fuerte: {FuerteArray[i]}");
        }

        Console.ReadKey();
    }
}