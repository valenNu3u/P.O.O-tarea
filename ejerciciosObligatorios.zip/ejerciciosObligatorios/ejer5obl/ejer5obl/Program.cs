﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer5obl
{
    public interface IEntregable
    {
        void entregar();
        void devolver();
        bool isEntregado();
        int compareTo(object a);
    }

    public class Serie : IEntregable
    {
        private string titulo;
        private int numeroTemporadas;
        private bool entregado;
        private string genero;
        private string creador;

        // Constructor por defecto
        public Serie()
        {
            this.titulo = string.Empty;
            this.numeroTemporadas = 3;
            this.entregado = false;
            this.genero = string.Empty;
            this.creador = string.Empty;
        }

        // Constructor con título y creador
        public Serie(string titulo, string creador)
        {
            this.titulo = titulo;
            this.numeroTemporadas = 3;
            this.entregado = false;
            this.genero = string.Empty;
            this.creador = creador;
        }

        // Constructor con todos los atributos menos "entregado"
        public Serie(string titulo, int numeroTemporadas, string genero, string creador)
        {
            this.titulo = titulo;
            this.numeroTemporadas = numeroTemporadas;
            this.entregado = false;
            this.genero = genero;
            this.creador = creador;
        }

        // Metodos Get
        public string GetTitulo() { return titulo; }
        public int GetNumeroTemporadas() { return numeroTemporadas; }
        public bool GetEntregado() { return entregado; }
        public string GetGenero() { return genero; }
        public string GetCreador() { return creador; }

        // Metodos Set
        public void SetTitulo(string titulo) { this.titulo = titulo; }
        public void SetNumeroTemporadas(int numeroTemporadas) { this.numeroTemporadas = numeroTemporadas; }
        public void SetGenero(string genero) { this.genero = genero; }
        public void SetCreador(string creador) { this.creador = creador; }
        public void SetEntregado(bool entregado) { this.entregado = entregado; }

        // Metodos de la interfaz entregable
        public void entregar() { this.entregado = true; }
        public void devolver() { this.entregado = false; }
        public bool isEntregado() { return entregado; }

        // El metodo compareTo(object a)
        public int compareTo(object a)
        {
            if (a is Serie)
            {
                Serie otraSerie = (Serie)a;
                return this.numeroTemporadas.CompareTo(otraSerie.numeroTemporadas);
            }
            else
            {
                return 0;
            }
        }
    }

    public class Videojuego : IEntregable
    {
        private string titulo;
        private int horasEstimadas;
        private bool entregado;
        private string genero;
        private string compania;

        // Constructor DEF
        public Videojuego()
        {
            this.titulo = string.Empty;
            this.horasEstimadas = 10;
            this.entregado = false;
            this.genero = string.Empty;
            this.compania = string.Empty;
        }

        // Constructor con el titulo y las horas estimadas
        public Videojuego(string titulo, int horasEstimadas)
        {
            this.titulo = titulo;
            this.horasEstimadas = horasEstimadas;
            this.entregado = false;
            this.genero = string.Empty;
            this.compania = string.Empty;
        }

        // Constructor con todos los atributos menos "entregado"
        public Videojuego(string titulo, int horasEstimadas, string genero, string compania)
        {
            this.titulo = titulo;
            this.horasEstimadas = horasEstimadas;
            this.entregado = false;
            this.genero = genero;
            this.compania = compania;
        }

        // Métodos Get
        public string GetTitulo() { return titulo; }
        public int GetHorasEstimadas() { return horasEstimadas; }
        public bool GetEntregado() { return entregado; }
        public string GetGenero() { return genero; }
        public string GetCompania() { return compania; }

        // Métodos Set
        public void SetTitulo(string titulo) { this.titulo = titulo; }
        public void SetHorasEstimadas(int horasEstimadas) { this.horasEstimadas = horasEstimadas; }
        public void SetGenero(string genero) { this.genero = genero; }
        public void SetCompania(string compania) { this.compania = compania; }
        public void SetEntregado(bool entregado) { this.entregado = entregado; }

        // Métodos de la interfaz Entregable
        public void entregar() { this.entregado = true; }
        public void devolver() { this.entregado = false; }
        public bool isEntregado() { return entregado; }

        // Método compareTo
        public int compareTo(object a)
        {
            if (a is Videojuego)
            {
                Videojuego otroVideojuego = (Videojuego)a;
                return this.horasEstimadas.CompareTo(otroVideojuego.horasEstimadas);
            }
            else
            {
                return 0;
            }
        }
    }

    class EntregablesApp
    {
        static void Main()
        {
            // estos son los arrays de Series y Videojuegos
            Serie[] series = new Serie[5];
            Videojuego[] videojuegos = new Videojuego[5];

            // aca estoy creando objetos en los arrays
            series[0] = new Serie("Murder Drones", "Liam Vickers");
            series[1] = new Serie("Belleza verdadera", "Studio Dragon");
            series[2] = new Serie("Fnaf High School", 5, "Drama", "Edoochan");
            series[3] = new Serie("Cliffside", 2, "Comedia", "Liam Vickers");
            series[4] = new Serie("Digital Circus", 4, "Drama Psicologico", "Gooseworx");

            videojuegos[0] = new Videojuego("Brawl Stars", 79);
            videojuegos[1] = new Videojuego("Rhythm Heaven Fever", 15);
            videojuegos[2] = new Videojuego("Friday Night Funkin'", 12, "Juego musical", "Newgrounds, NinjaMuffin99");
            videojuegos[3] = new Videojuego("The Last of Us", 20, "Aventura", "Neil Druckmann, Bruce Straley");
            videojuegos[4] = new Videojuego("Cuphead", 10, "Run and Gun", "Studio MDHR");

            // Entrega algunos videojuegos y series
            series[1].entregar();
            videojuegos[2].entregar();
            videojuegos[4].entregar();

            // Esto cuenta cuantos estan entregados
            int entregadosSeries = 0, entregadosVideojuegos = 0;
            foreach (Serie serie in series)
            {
                if (serie.isEntregado()) entregadosSeries++;
            }
            foreach (Videojuego videojuego in videojuegos)
            {
                if (videojuego.isEntregado()) entregadosVideojuegos++;
            }

            Console.WriteLine($"Series entregadas: {entregadosSeries}");
            Console.WriteLine($"Videojuegos entregados: {entregadosVideojuegos}");

            // Esto devuelve los entregados
            foreach (Serie serie in series)
            {
                if (serie.isEntregado()) serie.devolver();
            }
            foreach (Videojuego videojuego in videojuegos)
            {
                if (videojuego.isEntregado()) videojuego.devolver();
            }

            // Esto mostrara el videojuego con mas horas y la serie con mas temporadas
            Videojuego videojuegoConMasHoras = videojuegos[0];
            Serie serieConMasTemporadas = series[0];

            foreach (Videojuego v in videojuegos)
            {
                if (v.compareTo(videojuegoConMasHoras) > 0)
                    videojuegoConMasHoras = v;
            }
            foreach (Serie s in series)
            {
                if (s.compareTo(serieConMasTemporadas) > 0)
                    serieConMasTemporadas = s;
            }

            Console.WriteLine($"Videojuego con mas horas estimadas: {videojuegoConMasHoras.GetTitulo()} ({videojuegoConMasHoras.GetHorasEstimadas()} horas)");
            Console.WriteLine($"Serie con mas temporadas: {serieConMasTemporadas.GetTitulo()} ({serieConMasTemporadas.GetNumeroTemporadas()} temporadas)");

            Console.ReadKey();
        }
    }
}
