﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer14obl
{
    public class Producto
    {
        private string nombre;
        private double precio;

        public Producto(string nombre, double precio)
        {
            this.nombre = nombre;
            this.precio = precio;
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public double Precio
        {
            get { return precio; }
            set { precio = value; }
        }

        public override string ToString()
        {
            return $"Nombre = {nombre}, Precio = {precio}";
        }

        public virtual double Calcular(int cantidad)
        {
            return precio * cantidad;
        }
    }

    public class Perecedero : Producto
    {
        private int diasACaducar;

        public Perecedero(int diasACaducar, string nombre, double precio) : base(nombre, precio)
        {
            this.diasACaducar = diasACaducar;
        }

        public int DiasACaducar
        {
            get { return diasACaducar; }
            set { diasACaducar = value; }
        }

        public override string ToString()
        {
            return base.ToString() + $", Dias a caducar = {diasACaducar}";
        }

        public override double Calcular(int cantidad)
        {
            double precioFinal = base.Calcular(cantidad);

            switch (diasACaducar)
            {
                case 1:
                    precioFinal /= 4;
                    break;
                case 2:
                    precioFinal /= 3;
                    break;
                case 3:
                    precioFinal /= 2;
                    break;
            }

            return precioFinal;
        }
    }

    public class NoPerecedero : Producto
    {
        private string tipo;

        public NoPerecedero(string tipo, string nombre, double precio) : base(nombre, precio)
        {
            this.tipo = tipo;
        }

        public string Tipo
        {
            get { return tipo; }
            set { tipo = value; }
        }

        public override string ToString()
        {
            return base.ToString() + $", Tipo = {tipo}";
        }
    }

    public class Program
    {
        public static void Main(string[] args)
        {
            
            Producto[] productos = new Producto[3];

            
            productos[0] = new Producto("Producto 1", 10);
            productos[1] = new Perecedero(1, "Producto 2", 20);
            productos[2] = new NoPerecedero("Tipo 1", "Producto 3", 5);

            // calculo el precio total
            double total = 0;
            foreach (var producto in productos)
            {
                total += producto.Calcular(5); 
            }

            Console.WriteLine("El total es " + total);
            Console.ReadKey();
        }
    }
}
