﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer6obl
{
    public class Libro
    {
        private int isbn;
        private string titulo;
        private string autor;
        private int numPaginas;

        public Libro(int isbn, string titulo, string autor, int numPaginas)
        {
            this.isbn = isbn;
            this.titulo = titulo;
            this.autor = autor;
            this.numPaginas = numPaginas;
        }

        public int GetISBN()
        {
            return isbn;
        }

        public void SetISBN(int isbn)
        {
            this.isbn = isbn;
        }

        public string GetTitulo()
        {
            return titulo;
        }

        public void SetTitulo(string titulo)
        {
            this.titulo = titulo;
        }

        public string GetAutor()
        {
            return autor;
        }

        public void SetAutor(string autor)
        {
            this.autor = autor;
        }

        public int GetNumPaginas()
        {
            return numPaginas;
        }

        public void SetNumPaginas(int numPaginas)
        {
            this.numPaginas = numPaginas;
        }

        public override string ToString()
        {
            return $"El libro \"{titulo}\" con ISBN {isbn} creado por {autor} tiene {numPaginas} paginas";
        }
    }

    public class Ejer_obl_6
    {
        public static void Main(string[] args)
        {
            Libro libro1 = new Libro(1111111111, "El Aleph", "Jorge Luis Borges", 60);
            Libro libro2 = new Libro(1111111112, "Los ojos del perro Siberiano", "Antonio Santa Ana", 40);

            Console.WriteLine(libro1.ToString());
            Console.WriteLine(libro2.ToString());

            libro1.SetNumPaginas(70);

            if (libro1.GetNumPaginas() > libro2.GetNumPaginas())
            {
                Console.WriteLine($"{libro1.GetTitulo()} tiene mas paginas");
            }
            else
            {
                Console.WriteLine($"{libro2.GetTitulo()} tiene mas paginas");

               
            }
            Console.ReadKey();
        }
    }
}
