﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer13obl
{
    public abstract class Empleado
    {
        private string nombre;
        private int edad;
        private double salario;

        public const double PLUS = 300;

        protected Empleado(string nombre, int edad, double salario)
        {
            this.nombre = nombre;
            this.edad = edad;
            this.salario = salario;
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public int Edad
        {
            get { return edad; }
            set { edad = value; }
        }

        public double Salario
        {
            get { return salario; }
            set { salario = value; }
        }

        public override string ToString()
        {
            return $"nombre = {nombre}, edad = {edad}, salario = {salario}, ";
        }

        
        public abstract bool Plus();
    }

    public class Comercial : Empleado
    {
        private double comision;

        public Comercial(double comision, string nombre, int edad, double salario) : base(nombre, edad, salario)
        {
            this.comision = comision;
        }

        // los metodos
        public double Comision
        {
            get { return comision; }
            set { comision = value; }
        }

        public override string ToString()
        {
            return base.ToString() + "comision = " + comision;
        }

        public override bool Plus()
        {
            if (base.Edad > 30 && this.comision > 200)
            {
                double nuevoSalario = base.Salario + PLUS;
                base.Salario = nuevoSalario;
                Console.WriteLine("Se le añadio el plus al empleado " + base.Nombre);
                return true;
            }
            return false;
        }
    }

    public class Repartidor : Empleado
    {
        private string zona;

        // este es el constructor
        public Repartidor(string zona, string nombre, int edad, double salario) : base(nombre, edad, salario)
        {
            this.zona = zona;
        }

        // estos son los metodos
        public string Zona
        {
            get { return zona; }
            set { zona = value; }
        }

        public override string ToString()
        {
            return base.ToString() + "zona = " + zona;
        }

        public override bool Plus()
        {
            if (base.Edad < 25 && this.zona.Equals("zona 3"))
            {
                double nuevoSalario = base.Salario + PLUS;
                base.Salario = nuevoSalario;
                Console.WriteLine("Se le añadio el plus al empleado " + base.Nombre);
                return true;
            }
            return false;
        }
    }

    public class Program
    {
        public static void Main(string[] args)
        {
            // Creamos los objetos
            Comercial c1 = new Comercial(300, "Draco", 37, 1000);
            Repartidor r1 = new Repartidor("zona 3", "Gale", 24, 900);

            // menciono para llamar a plus
            c1.Plus();
            r1.Plus();

            Console.WriteLine(c1);
            Console.WriteLine(r1);
            Console.ReadKey();
        }
    }
}