﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer17obl
{
    public enum PalosBarajaEspañola
    {
        OROS, COPAS, ESPADAS, BASTOS
    }

    public enum PalosBarajaFrancesa
    {
        CORAZONES, DIAMANTES, TREBOLES, PICAS
    }

    public class Carta<T>
    {
        private int numero;
        private T palo;

        public Carta(int numero, T palo)
        {
            this.numero = numero;
            this.palo = palo;
        }

        public int getNumero()
        {
            return numero;
        }

        public T getPalo()
        {
            return palo;
        }

        public override string ToString()
        {
            return $"{numero} de {palo}";
        }
    }

    public abstract class Baraja<T>
    {
        protected Carta<T>[] cartas;
        protected int posSiguienteCarta;
        protected int numCartas;
        protected int cartasPorPalo;

        public Baraja()
        {
            this.posSiguienteCarta = 0;
        }

        public abstract void crearBaraja();

        public void barajar()
        {
            Random random = new Random();
            for (int i = 0; i < cartas.Length; i++)
            {
                int posAleatoria = random.Next(0, numCartas);
                Carta<T> c = cartas[i];
                cartas[i] = cartas[posAleatoria];
                cartas[posAleatoria] = c;
            }
            this.posSiguienteCarta = 0;
        }

        public Carta<T> siguienteCarta()
        {
            if (posSiguienteCarta == numCartas)
            {
                Console.WriteLine("Ya no hay mas cartas, barajear de nuevo");
                return null;
            }
            else
            {
                return cartas[posSiguienteCarta++];
            }
        }

        public Carta<T>[] darCartas(int numCartasSolicitadas)
        {
            if (numCartasSolicitadas > numCartas)
            {
                Console.WriteLine("No se puede dar mas cartas de las que ya hay");
                return null;
            }
            else if (cartasDisponible() < numCartasSolicitadas)
            {
                Console.WriteLine("No hay suficientes cartas disponibles");
                return null;
            }
            else
            {
                Carta<T>[] cartasDar = new Carta<T>[numCartasSolicitadas];
                for (int i = 0; i < numCartasSolicitadas; i++)
                {
                    cartasDar[i] = siguienteCarta();
                }
                return cartasDar;
            }
        }

        public int cartasDisponible()
        {
            return numCartas - posSiguienteCarta;
        }

        public void cartasMonton()
        {
            if (cartasDisponible() == numCartas)
            {
                Console.WriteLine("No se ha sacado ninguna carta");
            }
            else
            {
                for (int i = 0; i < posSiguienteCarta; i++)
                {
                    Console.WriteLine(cartas[i]);
                }
            }
        }

        public void mostrarBaraja()
        {
            if (cartasDisponible() == 0)
            {
                Console.WriteLine("No hay cartas que mostrar");
            }
            else
            {
                for (int i = posSiguienteCarta; i < cartas.Length; i++)
                {
                    Console.WriteLine(cartas[i]);
                }
            }
        }
    }

    public class BarajaEspañola : Baraja<PalosBarajaEspañola>
    {
        private bool incluye8Y9;

        public BarajaEspañola(bool incluye8Y9)
        {
            this.incluye8Y9 = incluye8Y9;
            if (incluye8Y9)
            {
                numCartas = 48;
                cartasPorPalo = 12;
            }
            else
            {
                numCartas = 40;
                cartasPorPalo = 10;
            }

            crearBaraja();
            barajar();
        }

        public override void crearBaraja()
        {
            cartas = new Carta<PalosBarajaEspañola>[numCartas];
            PalosBarajaEspañola[] palos = (PalosBarajaEspañola[])Enum.GetValues(typeof(PalosBarajaEspañola));

            for (int i = 0; i < palos.Length; i++)
            {
                for (int j = 0; j < cartasPorPalo; j++)
                {
                    if (incluye8Y9)
                    {
                        cartas[(i * cartasPorPalo) + j] = new Carta<PalosBarajaEspañola>(j + 1, palos[i]);
                    }
                    else
                    {
                        if (j >= 7)
                        {
                            cartas[(i * cartasPorPalo) + j] = new Carta<PalosBarajaEspañola>(j + 3, palos[i]);
                        }
                        else
                        {
                            cartas[(i * cartasPorPalo) + j] = new Carta<PalosBarajaEspañola>(j + 1, palos[i]);
                        }
                    }
                }
            }
        }
    }

    public class BarajaFrancesa : Baraja<PalosBarajaFrancesa>
    {
        public BarajaFrancesa()
        {
            numCartas = 52;
            cartasPorPalo = 13;
            crearBaraja();
            barajar();
        }

        public override void crearBaraja()
        {
            cartas = new Carta<PalosBarajaFrancesa>[numCartas];
            PalosBarajaFrancesa[] palos = (PalosBarajaFrancesa[])Enum.GetValues(typeof(PalosBarajaFrancesa));

            for (int i = 0; i < palos.Length; i++)
            {
                for (int j = 0; j < cartasPorPalo; j++)
                {
                    cartas[(i * cartasPorPalo) + j] = new Carta<PalosBarajaFrancesa>(j + 1, palos[i]);
                }
            }
        }

        public bool cartaRoja(Carta<PalosBarajaFrancesa> c)
        {
            return c.getPalo() == PalosBarajaFrancesa.CORAZONES || c.getPalo() == PalosBarajaFrancesa.DIAMANTES;
        }

        public bool cartaNegra(Carta<PalosBarajaFrancesa> c)
        {
            return c.getPalo() == PalosBarajaFrancesa.TREBOLES || c.getPalo() == PalosBarajaFrancesa.PICAS;
        }
    }
    public class Program
    {
        public static void Main()
        {
            // Baraja española
            BarajaEspañola barajaEspañola = new BarajaEspañola(true);
            Console.WriteLine("Baraja Española:");
            barajaEspañola.mostrarBaraja();
            Console.WriteLine("\n");

            // Baraja francesa
            BarajaFrancesa barajaFrancesa = new BarajaFrancesa();
            Console.WriteLine("Baraja Francesa:");
            barajaFrancesa.mostrarBaraja();
            Console.ReadKey();
        }
    }
}
