﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer7obl
{
        public class Raices
        {
            private double a;
            private double b;
            private double c;

            public Raices(double a, double b, double c)
            {
                this.a = a;
                this.b = b;
                this.c = c;
            }

            private void ObtenerRaices()
            {
                double x1 = (-b + Math.Sqrt(GetDiscriminante())) / (2 * a);
                double x2 = (-b - Math.Sqrt(GetDiscriminante())) / (2 * a);

                Console.WriteLine("Primera raiz x1:");
                Console.WriteLine(x1);
                Console.WriteLine("Segunda raiz x2:");
                Console.WriteLine(x2);
            }

            private void ObtenerRaiz()
            {
                double x = (-b) / (2 * a);

                Console.WriteLine("La unica solucion es:");
                Console.WriteLine(x);
            }

            private double GetDiscriminante()
            {
                return Math.Pow(b, 2) - (4 * a * c);
            }

            private bool TieneRaices()
            {
                return GetDiscriminante() > 0;
            }

            private bool TieneRaiz()
            {
                return GetDiscriminante() == 0;
            }

            public void Calcular()
            {
                if (TieneRaices())
                {
                    ObtenerRaices();
                }
                else if (TieneRaiz())
                {
                    ObtenerRaiz();
                }
                else
                {
                    Console.WriteLine("No tiene soluciones");
                }
                Console.ReadKey();
            }
            public class ejer_obl_7
            {
                public static void Main(string[] args)
                {
                    Raices ecuacion = new Raices(1, 4, 4); // esto crea el obj
                    ecuacion.Calcular(); // esto calcula las soluciones
                }
            }
        }
    }