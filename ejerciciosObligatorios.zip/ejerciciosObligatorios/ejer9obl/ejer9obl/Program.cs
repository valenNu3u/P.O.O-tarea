﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Espectador
{
    private string nombre;
    private int edad;
    private double dinero;

    // Constructores
    public Espectador(string nombre, int edad, double dinero)
    {
        this.nombre = nombre;
        this.edad = edad;
        this.dinero = dinero;
    }

    // Métodos
    public string GetNombre()
    {
        return nombre;
    }

    public void SetNombre(string nombre)
    {
        this.nombre = nombre;
    }

    public int GetEdad()
    {
        return edad;
    }

    public void SetEdad(int edad)
    {
        this.edad = edad;
    }

    public double GetDinero()
    {
        return dinero;
    }

    public void SetDinero(double dinero)
    {
        this.dinero = dinero;
    }

    public void Pagar(double precio)
    {
        dinero -= precio;
    }

    public bool TieneEdad(int edadMinima)
    {
        return edad >= edadMinima;
    }

    public bool TieneDinero(double precioEntrada)
    {
        return dinero >= precioEntrada;
    }

    public override string ToString()
    {
        return $"El espectador es {nombre}, tiene {edad} años y {dinero} pesos";
    }
}

public class Asiento
{
    private char letra;
    private int fila;
    private Espectador espectador;

    public Asiento(char letra, int fila)
    {
        this.letra = letra;
        this.fila = fila;
        this.espectador = null;
    }

    public char GetLetra()
    {
        return letra;
    }

    public void SetLetra(char letra)
    {
        this.letra = letra;
    }

    public int GetFila()
    {
        return fila;
    }

    public void SetFila(int fila)
    {
        this.fila = fila;
    }

    public Espectador GetEspectador()
    {
        return espectador;
    }

    public void SetEspectador(Espectador espectador)
    {
        this.espectador = espectador;
    }

    public bool Ocupado()
    {
        return espectador != null;
    }

    public override string ToString()
    {
        if (Ocupado())
        {
            return $"Asiento: {fila}{letra} y {espectador}";
        }
        return $"Asiento: {fila}{letra} , estos asientos estan vacios";
    }
}

public class Pelicula
{
    private string titulo;
    private int duracion;
    private int edadMinima;
    private string director;

    public Pelicula(string titulo, int duracion, int edadMinima, string director)
    {
        this.titulo = titulo;
        this.duracion = duracion;
        this.edadMinima = edadMinima;
        this.director = director;
    }

    public string GetTitulo()
    {
        return titulo;
    }

    public void SetTitulo(string titulo)
    {
        this.titulo = titulo;
    }

    public int GetDuracion()
    {
        return duracion;
    }

    public void SetDuracion(int duracion)
    {
        this.duracion = duracion;
    }

    public int GetEdadMinima()
    {
        return edadMinima;
    }

    public void SetEdadMinima(int edadMinima)
    {
        this.edadMinima = edadMinima;
    }

    public string GetDirector()
    {
        return director;
    }

    public void SetDirector(string director)
    {
        this.director = director;
    }

    public override string ToString()
    {
        return $"'{titulo}' del director {director}, dura {duracion} minutos y la edad permitida es {edadMinima} años.";
    }
}

public class Cine
{
    private Asiento[,] asientos;
    private double precio;
    private Pelicula pelicula;

    public Cine(int filas, int columnas, double precio, Pelicula pelicula)
    {
        asientos = new Asiento[filas, columnas];
        this.precio = precio;
        this.pelicula = pelicula;
        RellenaButacas();
    }

    public Asiento[,] GetAsientos()
    {
        return asientos;
    }

    public void SetAsientos(Asiento[,] asientos)
    {
        this.asientos = asientos;
    }

    public double GetPrecio()
    {
        return precio;
    }

    public void SetPrecio(double precio)
    {
        this.precio = precio;
    }

    public Pelicula GetPelicula()
    {
        return pelicula;
    }

    public void SetPelicula(Pelicula pelicula)
    {
        this.pelicula = pelicula;
    }

    private void RellenaButacas()
    {
        int fila = asientos.GetLength(0);
        for (int i = 0; i < asientos.GetLength(0); i++)
        {
            for (int j = 0; j < asientos.GetLength(1); j++)
            {
                asientos[i, j] = new Asiento((char)('A' + j), fila);
            }
            fila--;
        }
    }

    public bool HaySitio()
    {
        foreach (var asiento in asientos)
        {
            if (!asiento.Ocupado())
            {
                return true;
            }
        }
        return false;
    }

    public bool HaySitioButaca(int fila, char letra)
    {
        return !GetAsiento(fila, letra).Ocupado();
    }

    public bool SePuedeSentar(Espectador e)
    {
        return e.TieneDinero(precio) && e.TieneEdad(pelicula.GetEdadMinima());
    }

    public void Sentar(int fila, char letra, Espectador e)
    {
        GetAsiento(fila, letra).SetEspectador(e);
    }

    public Asiento GetAsiento(int fila, char letra)
    {
        int filaIndex = asientos.GetLength(0) - fila; 
        int colIndex = letra - 'A'; 

        if (filaIndex < 0 || filaIndex >= asientos.GetLength(0) || colIndex < 0 || colIndex >= asientos.GetLength(1))
        {
            Console.WriteLine("Este asiento no se permite");
        }

        return asientos[filaIndex, colIndex];
    }

    public int GetFilas()
    {
        return asientos.GetLength(0);
    }

    public int GetColumnas()
    {
        return asientos.GetLength(1);
    }

    public void Mostrar()
    {
        Console.WriteLine("Información del cine");
        Console.WriteLine($"Pelicula que se vera: {pelicula}");
        Console.WriteLine($"Precio de la entrada: {precio}\n");

        for (int i = 0; i < asientos.GetLength(0); i++)
        {
            for (int j = 0; j < asientos.GetLength(1); j++)
            {
                Console.WriteLine(asientos[i, j]);
            }
            Console.WriteLine();
        }
    }
}

public static class Metodos
{
    private static Random rnd = new Random();  // Random estático para valores únicos
    public static readonly string[] nombres = { "Mico", "Tick", "Rico", "Piper", "Nita", "Sandy", "Duki", "Emilia", "Lola", "Gray" };

    public static int GeneraNumEnteroAleatorio(int minimo, int maximo)
    {
        return rnd.Next(minimo, maximo + 1);
    }
}

public class Principal
{
    public static void Main(string[] args)
    {
        Pelicula pelicula = new Pelicula("La razon de estar contigo", 120, 13, "Lasse Hallström");

        Console.WriteLine("Número de filas:");
        int filas = int.Parse(Console.ReadLine());

        Console.WriteLine("Número de columnas:");
        int columnas = int.Parse(Console.ReadLine());

        Console.WriteLine("Precio del cine:");
        double precio = double.Parse(Console.ReadLine());

        Cine cine = new Cine(filas, columnas, precio, pelicula);

        Console.WriteLine("Personas que veran la pelicula:");
        int numEspectadores = int.Parse(Console.ReadLine());

        Espectador e;
        int fila;
        char letra;

        Console.WriteLine("Los espectadores son:");
        for (int i = 0; i < numEspectadores && cine.HaySitio(); i++)
        {
            e = new Espectador(
                Metodos.nombres[Metodos.GeneraNumEnteroAleatorio(0, Metodos.nombres.Length - 1)],
                Metodos.GeneraNumEnteroAleatorio(10, 30),
                Metodos.GeneraNumEnteroAleatorio(2000, 10000) // el dinero podra estar entre 2000 y 10000
            );

            Console.WriteLine(e);

            do
            {
                fila = Metodos.GeneraNumEnteroAleatorio(1, cine.GetFilas()); // 
                int colIndex = Metodos.GeneraNumEnteroAleatorio(0, cine.GetColumnas() - 1); // indice de columna

                letra = (char)('A' + colIndex); // esto convierte el indice a la letra que corresponda

            } while (!cine.HaySitioButaca(fila, letra));

            if (cine.SePuedeSentar(e))
            {
                e.Pagar(cine.GetPrecio());
                cine.Sentar(fila, letra, e);
                Console.WriteLine($"{e.GetNombre()} se le asigno el asiento {fila}{letra}\n");
            }
            else
            {
                Console.WriteLine($"{e.GetNombre()} no cumple con la edad o el dinero requerido\n");
            }
        }

        cine.Mostrar();
        Console.ReadKey();
    }
}

