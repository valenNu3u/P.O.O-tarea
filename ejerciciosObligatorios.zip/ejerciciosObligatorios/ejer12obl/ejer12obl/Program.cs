﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer12obl
{
    public class Revolver
    {
        private int posicionActual;
        private int posicionBala;
        private static Random rand = new Random();

        public Revolver()
        {
            posicionActual = rand.Next(1, 7);  // posición aleatoria entre 1 y 6
            posicionBala = rand.Next(1, 7);    // posición aleatoria entre 1 y 6
        }

        public bool Disparar()
        {
            return posicionActual == posicionBala;
        }

        public void SiguienteBala()
        {
            posicionActual = (posicionActual % 6) + 1;  
        }
    }

    public class Jugador
    {
        public int Id { get; private set; }
        public string Nombre { get; private set; }
        public bool Vivo { get; private set; }

        public Jugador(int id)
        {
            Id = id;
            Nombre = "jugador " + id;
            Vivo = true;
        }

        public void Disparar(Revolver revolver)
        {
            if (Vivo)
            {
                Console.WriteLine($"el {Nombre} se apunta-");
                if (revolver.Disparar())
                {
                    Vivo = false;
                    Console.WriteLine($"el {Nombre} ha muerto.");
                }
                else
                {
                    Console.WriteLine($"el {Nombre} sobrevivio.");
                }
            }
        }
    }

    public class Juego
    {
        private List<Jugador> jugadores;
        private Revolver revolver;

        public Juego(int numeroJugadores)
        {
            jugadores = new List<Jugador>();
            revolver = new Revolver();

            // me aseguro que el numero de jugadores esté entre 1 y 6
            numeroJugadores = (numeroJugadores < 1 || numeroJugadores > 6) ? 6 : numeroJugadores;

            for (int i = 1; i <= numeroJugadores; i++)
            {
                jugadores.Add(new Jugador(i));
            }
        }

        public bool FinJuego()
        {
            return jugadores.Find(jugador => jugador.Vivo) == null;
        }

        public void Ronda()
        {
            foreach (var jugador in jugadores)
            {
                if (jugador.Vivo)
                {
                    jugador.Disparar(revolver);
                    if (FinJuego()) return;
                    revolver.SiguienteBala();
                }
            }
        }
    }

    public class Program
    {
        public static void Main()
        {
            int numJugadores;
            Console.Write("Ingrese el número de jugadores (1 a 6): ");
            while (!int.TryParse(Console.ReadLine(), out numJugadores) || numJugadores < 1 || numJugadores > 6)
            {
                Console.Write("Incorrecto, el número debe estar entre 1 y 6: ");
            }

            // Creo el juego con el número de jugadores
            Juego juego = new Juego(numJugadores);

            // Jugamos hasta que se termine
            while (!juego.FinJuego())
            {
                juego.Ronda();
            }

            Console.WriteLine("El juego termino.");
            Console.ReadKey();
        }
    }
}
