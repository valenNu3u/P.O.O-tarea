﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer16obl
{
    public class Contacto
    {
        private string nombre;
        private int telefono;

        public Contacto(string nombre, int telefono)
        {
            this.nombre = nombre;
            this.telefono = telefono;
        }

        public Contacto(string nombre)
        {
            this.nombre = nombre;
            this.telefono = 0;
        }

        public string GetNombre()
        {
            return nombre;
        }

        public int GetTelefono()
        {
            return telefono;
        }

        public void SetTelefono(int telefono)
        {
            this.telefono = telefono;
        }

        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType()) return false;

            Contacto c = (Contacto)obj;
            return nombre.Trim().Equals(c.GetNombre().Trim(), StringComparison.OrdinalIgnoreCase);
        }

        public override string ToString()
        {
            return $"Nombre: {nombre}, Telefono: {telefono}";
        }
    }

    public class Agenda
    {
        private Contacto[] contactos;

        public Agenda(int tamanio = 10)
        {
            contactos = new Contacto[tamanio];
        }

        public void AniadirContacto(Contacto c)
        {
            if (ExisteContacto(c))
            {
                Console.WriteLine("El contacto con ese nombre ya existe");
            }
            else if (AgendaLlena())
            {
                Console.WriteLine("La agenda esta llena, no se pueden meter más contactos");
            }
            else
            {
                bool encontrado = false;
                for (int i = 0; i < contactos.Length && !encontrado; i++)
                {
                    if (contactos[i] == null)
                    {
                        contactos[i] = c;
                        encontrado = true;
                        Console.WriteLine("Se ha añadido el contacto");
                    }
                }
            }
        }

        public bool ExisteContacto(Contacto c)
        {
            foreach (var contacto in contactos)
            {
                if (contacto != null && contacto.Equals(c))
                {
                    return true;
                }
            }
            return false;
        }

        public void ListarContactos()
        {
            bool hayContactos = false;
            foreach (var contacto in contactos)
            {
                if (contacto != null)
                {
                    Console.WriteLine(contacto);
                    hayContactos = true;
                }
            }
            if (!hayContactos) Console.WriteLine("No hay contactos que mostrar");
        }

        public void BuscarPorNombre(string nombre)
        {
            bool encontrado = false;
            foreach (var contacto in contactos)
            {
                if (contacto != null && contacto.GetNombre().Trim().Equals(nombre.Trim(), StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine($"Su telefono es {contacto.GetTelefono()}");
                    encontrado = true;
                    break;
                }
            }
            if (!encontrado) Console.WriteLine("No se ha encontrado el contacto");
        }

        public bool AgendaLlena()
        {
            foreach (var contacto in contactos)
            {
                if (contacto == null) return false;
            }
            return true;
        }

        public void EliminarContacto(Contacto c)
        {
            bool encontrado = false;
            for (int i = 0; i < contactos.Length && !encontrado; i++)
            {
                if (contactos[i] != null && contactos[i].Equals(c))
                {
                    contactos[i] = null;
                    encontrado = true;
                    Console.WriteLine("Se ha eliminado el contacto");
                }
            }
            if (!encontrado) Console.WriteLine("No se ha eliminado el contacto");
        }

        public int HuecosLibres()
        {
            int contadorLibres = 0;
            foreach (var contacto in contactos)
            {
                if (contacto == null) contadorLibres++;
            }
            return contadorLibres;
        }
    }

    class Program
    {
        static void Main()
        {
            Agenda agendaTelefonica = new Agenda(3);
            bool salir = false;

            while (!salir)
            {
                Console.WriteLine("1. Añadir contacto");
                Console.WriteLine("2. Listar contactos");
                Console.WriteLine("3. Buscar contacto");
                Console.WriteLine("4. Existe contacto");
                Console.WriteLine("5. Eliminar contacto");
                Console.WriteLine("6. Contactos disponibles");
                Console.WriteLine("7. Agenda llena");
                Console.WriteLine("8. Salir");

                Console.Write("Escribe una de las opciones: ");
                int opcion;
                if (int.TryParse(Console.ReadLine(), out opcion))
                {
                    string nombre;
                    int telefono;
                    Contacto c;

                    switch (opcion)
                    {
                        case 1:
                            Console.Write("Escribe un nombre: ");
                            nombre = Console.ReadLine();

                            Console.Write("Escribe un telefono: ");
                            if (int.TryParse(Console.ReadLine(), out telefono))
                            {
                                c = new Contacto(nombre, telefono);
                                agendaTelefonica.AniadirContacto(c);
                            }
                            else
                            {
                                Console.WriteLine("Telefono invalido.");
                            }
                            break;

                        case 2:
                            agendaTelefonica.ListarContactos();
                            break;

                        case 3:
                            Console.Write("Escribe un nombre: ");
                            nombre = Console.ReadLine();
                            agendaTelefonica.BuscarPorNombre(nombre);
                            break;

                        case 4:
                            Console.Write("Escribe un nombre: ");
                            nombre = Console.ReadLine();
                            c = new Contacto(nombre);
                            Console.WriteLine(agendaTelefonica.ExisteContacto(c) ? "Existe el contacto" : "No existe el contacto");
                            break;

                        case 5:
                            Console.Write("Escribe un nombre: ");
                            nombre = Console.ReadLine();
                            c = new Contacto(nombre);
                            agendaTelefonica.EliminarContacto(c);
                            break;

                        case 6:
                            Console.WriteLine($"Hay {agendaTelefonica.HuecosLibres()} contactos libres");
                            break;

                        case 7:
                            Console.WriteLine(agendaTelefonica.AgendaLlena() ? "La agenda esta llena" : "Todavia podes meter contactos");
                            break;

                        case 8:
                            salir = true;
                            break;

                        default:
                            Console.WriteLine("Solo ingresar numeros entre 1 y 8");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Debes ingresar un numero valido");
                }
                Console.ReadKey();
            }
        }
    }
}
