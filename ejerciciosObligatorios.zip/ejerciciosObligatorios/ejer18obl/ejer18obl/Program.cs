﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ejer18obl
{  

    public class Opcion
    {
        public string Texto { get; set; }
        public bool EsCorrecta { get; set; }
    }

    public class Pregunta
    {
        public string Texto { get; set; }
        public List<Opcion> Opciones { get; set; }
        public int OpcionCorrecta { get; set; }
        public int Puntos { get; set; }

        public void MostrarPregunta()
        {
            Console.WriteLine(Texto);
            for (int i = 0; i < Opciones.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Opciones[i].Texto}");
            }
        }

        public bool ComprobarRespuesta(int respuestaUsuario)
        {
            return respuestaUsuario == OpcionCorrecta;
        }
    }

    public class Test
    {
        private List<Pregunta> preguntas;
        private int preguntaActual;
        private int puntosTotales;

        public Test()
        {
            preguntas = new List<Pregunta>();
            preguntaActual = 0;
            puntosTotales = 0;
        }

        public void CargarPreguntas(string fichero)
        {
            preguntas.Clear();
            List<string> lineas = new List<string>(File.ReadLines(fichero));  

            Pregunta preguntaActual = null;

            foreach (var linea in lineas)
            {
                string textoLinea = linea.Trim();

                if (textoLinea.StartsWith(";P;"))
                {
                    if (preguntaActual != null)
                    {
                        preguntas.Add(preguntaActual);
                    }

                    preguntaActual = new Pregunta
                    {
                        Texto = textoLinea.Substring(3).Trim(),
                        Opciones = new List<Opcion>()
                    };
                }
                else if (textoLinea.StartsWith(";R;"))
                {
                    if (preguntaActual != null)
                    {
                        preguntaActual.OpcionCorrecta = int.Parse(textoLinea.Substring(3).Trim());
                    }
                }
                else if (textoLinea.StartsWith(";"))
                {
                    
                    continue;
                }
                else
                {
                    if (preguntaActual != null)
                    {
                        Opcion opcion = new Opcion
                        {
                            Texto = textoLinea.Trim(),
                            EsCorrecta = false
                        };
                        preguntaActual.Opciones.Add(opcion);
                    }
                }
            }

            if (preguntaActual != null)
            {
                preguntas.Add(preguntaActual);
            }
        }

        public void SiguientePregunta()
        {
            if (preguntaActual < preguntas.Count)
            {
                preguntas[preguntaActual].MostrarPregunta();
            }
            else
            {
                Console.WriteLine("El test termino");
            }
        }

        public void RealizarTest()
        {
            while (preguntaActual < preguntas.Count)
            {
                preguntas[preguntaActual].MostrarPregunta();
                Console.Write("Elegi una opcion: ");
                int respuestaUsuario = int.Parse(Console.ReadLine());

                if (preguntas[preguntaActual].ComprobarRespuesta(respuestaUsuario))
                {
                    puntosTotales += preguntas[preguntaActual].Puntos;
                    Console.WriteLine("Respuesta correcta");
                }
                else
                {
                    Console.WriteLine("Respuesta incorrecta");
                }

                preguntaActual++;
            }

            Console.WriteLine($"Puntos totales: {puntosTotales}");
        }

        public void ReiniciarTest()
        {
            preguntaActual = 0;
            puntosTotales = 0;
        }
    }

    public class Program
    {
        public static void Main()
        {
            Test test = new Test();

            test.CargarPreguntas("preguntas.txt");

            test.RealizarTest();
            
            Console.ReadKey();
        }
    }
}
