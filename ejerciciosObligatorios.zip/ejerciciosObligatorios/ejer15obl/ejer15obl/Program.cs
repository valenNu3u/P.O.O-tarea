﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer15obl
{
    public class Bebida
    {
        private static int idActual = 1;
        private int id;
        private double cantidad;
        private double precio;
        private string marca;

        public Bebida(double cantidad, double precio, string marca)
        {
            this.id = idActual++;
            this.cantidad = cantidad;
            this.precio = precio;
            this.marca = marca;
        }

        public int GetId()
        {
            return id;
        }

        public double GetCantidad()
        {
            return cantidad;
        }

        public void SetCantidad(double cantidad)
        {
            this.cantidad = cantidad;
        }

        public double GetPrecio()
        {
            return precio;
        }

        public void SetPrecio(double precio)
        {
            this.precio = precio;
        }

        public string GetMarca()
        {
            return marca;
        }

        public void SetMarca(string marca)
        {
            this.marca = marca;
        }

        public override string ToString()
        {
            return $"id={id}, cantidad={cantidad}, precio={precio}, marca={marca} ";
        }
    }

    public class BebidaAzucarada : Bebida
    {
        private double porcentajeAzucar;
        private bool promocion;

        public BebidaAzucarada(double porcentajeAzucar, bool promocion, double cantidad, double precio, string marca)
            : base(cantidad, precio, marca)
        {
            this.porcentajeAzucar = porcentajeAzucar;
            this.promocion = promocion;
        }

        public double GetPorcentajeAzucar()
        {
            return porcentajeAzucar;
        }

        public void SetPorcentajeAzucar(double porcentajeAzucar)
        {
            this.porcentajeAzucar = porcentajeAzucar;
        }

        public bool IsPromocion()
        {
            return promocion;
        }

        public void SetPromocion(bool promocion)
        {
            this.promocion = promocion;
        }

        public new double GetPrecio()
        {
            return promocion ? base.GetPrecio() * 0.9 : base.GetPrecio();
        }

        public override string ToString()
        {
            return base.ToString() + $"porcentajeAzucar={porcentajeAzucar}, promocion={promocion}";
        }
    }

    public class AguaMineral : Bebida
    {
        private string manantial;

        public AguaMineral(string manantial, double cantidad, double precio, string marca)
            : base(cantidad, precio, marca)
        {
            this.manantial = manantial;
        }

        public string GetManantial()
        {
            return manantial;
        }

        public void SetManantial(string manantial)
        {
            this.manantial = manantial;
        }

        public override string ToString()
        {
            return base.ToString() + $"manantial={manantial}";
        }
    }

    public class Almacen
    {
        private Bebida[,] estanteria;

        public Almacen(int filas, int columnas)
        {
            estanteria = new Bebida[filas, columnas];
        }

        public Almacen()
        {
            estanteria = new Bebida[5, 5];
        }

        public void AgregarBebida(Bebida b)
        {
            bool encontrado = false;
            for (int i = 0; i < estanteria.GetLength(0) && !encontrado; i++)
            {
                for (int j = 0; j < estanteria.GetLength(1) && !encontrado; j++)
                {
                    if (estanteria[i, j] == null)
                    {
                        estanteria[i, j] = b;
                        encontrado = true;
                    }
                }
            }
            Console.WriteLine(encontrado ? "Bebida añadida" : "No se ha podido añadir la bebida");
        }

        public void EliminarBebida(int id)
        {
            bool encontrado = false;
            for (int i = 0; i < estanteria.GetLength(0) && !encontrado; i++)
            {
                for (int j = 0; j < estanteria.GetLength(1) && !encontrado; j++)
                {
                    if (estanteria[i, j] != null && estanteria[i, j].GetId() == id)
                    {
                        estanteria[i, j] = null;
                        encontrado = true;
                    }
                }
            }
            Console.WriteLine(encontrado ? "Bebida eliminada" : "No existe la bebida");
        }

        public void MostrarBebidas()
        {
            for (int i = 0; i < estanteria.GetLength(0); i++)
            {
                for (int j = 0; j < estanteria.GetLength(1); j++)
                {
                    if (estanteria[i, j] != null)
                    {
                        Console.WriteLine($"fila {i}, columna: {j} Bebida: {estanteria[i, j]}");
                    }
                }
            }
        }

        public double CalcularPrecioBebidas()
        {
            double precioTotal = 0;
            for (int i = 0; i < estanteria.GetLength(0); i++)
            {
                for (int j = 0; j < estanteria.GetLength(1); j++)
                {
                    if (estanteria[i, j] != null)
                    {
                        precioTotal += estanteria[i, j].GetPrecio();
                    }
                }
            }
            return precioTotal;
        }

        public double CalcularPrecioBebidas(string marca)
        {
            double precioTotal = 0;
            for (int i = 0; i < estanteria.GetLength(0); i++)
            {
                for (int j = 0; j < estanteria.GetLength(1); j++)
                {
                    if (estanteria[i, j] != null && estanteria[i, j].GetMarca() == marca)
                    {
                        precioTotal += estanteria[i, j].GetPrecio();
                    }
                }
            }
            return precioTotal;
        }

        public double CalcularPrecioBebidas(int columna)
        {
            double precioTotal = 0;
            if (columna >= 0 && columna < estanteria.GetLength(1))
            {
                for (int i = 0; i < estanteria.GetLength(0); i++)
                {
                    if (estanteria[i, columna] != null)
                    {
                        precioTotal += estanteria[i, columna].GetPrecio();
                    }
                }
            }
            else
            {
                Console.WriteLine("La columna debe estar entre 0 y " + (estanteria.GetLength(1) - 1));
            }
            return precioTotal;
        }
    }

    public class Ejer_obl_15
    {
        public static void Main(string[] args)
        {
            Almacen a = new Almacen();
            Bebida b;

            for (int i = 0; i < 10; i++)
            {
                if (i % 2 == 0)
                {
                    b = new AguaMineral("Villavicencio", 1.5, 5, "Lagoa");
                }
                else
                {
                    b = new BebidaAzucarada(0.2, true, 1.5, 10, "Coca Cola");
                }
                a.AgregarBebida(b);
            }

            Console.WriteLine("--- Inventario Inicial ---");
            a.MostrarBebidas();
            Console.WriteLine($"El precio de todas las bebidas es: {a.CalcularPrecioBebidas()}");

            a.EliminarBebida(4);

            Console.WriteLine("----------- Inventario Después de Eliminar Bebida ID 4 ----------");
            a.MostrarBebidas();
            Console.WriteLine($"El precio de todas las bebidas es: {a.CalcularPrecioBebidas()}");
            Console.WriteLine($"El precio de todas las bebidas de la marca Lagoa es: {a.CalcularPrecioBebidas("Lagoa")}");
            Console.WriteLine($"Calcular el precio de la columna 0: {a.CalcularPrecioBebidas(0)}");
            Console.ReadKey();
        }
    }
}
