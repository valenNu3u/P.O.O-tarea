﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer10obl
{
    public class Carta
    {
        private int numero;
        private string palo;

        public static String[] PALOS = { "ESPADAS", "OROS", "COPAS", "BASTOS" };
        public static int LIMITE_CARTA_PALO = 12;

        public Carta(int numero, String palo)
        {
            this.numero = numero;
            this.palo = palo;
        }

        public override string ToString()
        {
            return "numero=" + numero + ", palo=" + palo;
        }
    }

    public class Baraja
    {
        private Carta[] cartas;
        private int posSiguienteCarta;

        public static int NUM_CARTAS = 40;

        public Baraja()
        {
            this.cartas = new Carta[NUM_CARTAS];
            this.posSiguienteCarta = 0;
            CrearBaraja(); 
            Barajar(); 
        }

        private void CrearBaraja()
        {
            string[] palos = Carta.PALOS;
            int var = 0;

            for (int i = 0; i < palos.Length; i++)
            {
                for (int j = 1; j <= Carta.LIMITE_CARTA_PALO; j++)
                {
                    if (j != 8 && j != 9) // Excluir 8 y 9
                    {
                        cartas[var++] = new Carta(j, palos[i]);
                    }
                }
            }
        }

        public void Barajar()
        {
            Random rand = new Random();
            for (int i = 0; i < cartas.Length; i++)
            {
                int posAleatoria = rand.Next(0, NUM_CARTAS);
                Carta aux = cartas[i];
                cartas[i] = cartas[posAleatoria];
                cartas[posAleatoria] = aux;
            }

            this.posSiguienteCarta = 0;
        }

        public Carta SiguienteCarta()
        {
            if (posSiguienteCarta >= NUM_CARTAS)
            {
                Console.WriteLine("No hay más cartas, baraja de nuevo.");
                return null;
            }
            return cartas[posSiguienteCarta++];
        }

        public Carta[] DarCartas(int numCartas)
        {
            if (numCartas > NUM_CARTAS)
            {
                Console.WriteLine("No es posible dar más cartas de las que hay en la baraja.");
                return null;
            }
            else if (CartasDisponibles() < numCartas)
            {
                Console.WriteLine("No hay suficientes cartas para mostrar.");
                return null;
            }
            else
            {
                Carta[] cartasDar = new Carta[numCartas];
                for (int i = 0; i < numCartas; i++)
                {
                    cartasDar[i] = SiguienteCarta();
                }
                return cartasDar;
            }
        }

        public int CartasDisponibles()
        {
            return NUM_CARTAS - posSiguienteCarta;
        }

        public void CartasMonton()
        {
            if (posSiguienteCarta == 0)
            {
                Console.WriteLine("No se ha sacado ninguna carta.");
            }
            else
            {
                Console.WriteLine("Cartas que han salido:");
                for (int i = 0; i < posSiguienteCarta; i++)
                {
                    Console.WriteLine(cartas[i]);
                }
            }
        }

        public void MostrarBaraja()
        {
            if (CartasDisponibles() == 0)
            {
                Console.WriteLine("No hay ninguna carta que mostrar");
            }
            else
            {
                Console.WriteLine("Cartas en la baraja:");
                for (int i = posSiguienteCarta; i < cartas.Length; i++)
                {
                    Console.WriteLine(cartas[i]);
                }
            }
        }
    }

    public static class Metodos
    {
        public static int NumEnteroAleatorio(int minimo, int maximo)
        {
            Random rand = new Random();
            return rand.Next(minimo, maximo + 1);
        }
    }

    class Ejer_obl_10
    {
        static void Main(string[] args)
        {
            // Creo la baraja
            Baraja b = new Baraja();

            Console.WriteLine("Hay " + b.CartasDisponibles() + " cartas disponibles");

            // Saco una carta
            b.SiguienteCarta();

            // Saco 5 cartas
            Carta[] cincoCartas = b.DarCartas(5);

            
            Console.WriteLine("Hay " + b.CartasDisponibles() + " cartas disponibles");

            Console.WriteLine("");
            b.CartasMonton();

            
            b.Barajar();

            
            Carta[] nuevasCartas = b.DarCartas(5);
            if (nuevasCartas != null)
            {
                Console.WriteLine("Cartas sacadas después de barajar:");
                foreach (var carta in nuevasCartas)
                {
                    Console.WriteLine(carta);
                }
                Console.ReadKey();
            }
        }
    }
}