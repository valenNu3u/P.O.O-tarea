﻿using ejer11obl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer11obl
{
    public interface IConstantes
        {
            int Num_Partidos { get; }
            int NUMERO_JORNADAS { get; }
            double DINERO_INICIAL { get; }
            int RESULTADO_MINIMO { get; }
            int RESULTADO_MAXIMO { get; }
            double DINERO_CADA_JORNADA { get; }
        }

        public class Constantes : IConstantes
        {
            public int Num_Partidos => 2;
            public int NUMERO_JORNADAS => 3;
            public double DINERO_INICIAL => 35;
            public int RESULTADO_MINIMO => 0;
            public int RESULTADO_MAXIMO => 3;
            public double DINERO_CADA_JORNADA => 1;
        }

        public class Jugador
        {
            private string nombre;
            private double dinero;
            private int porrasGanadas;
            private string[] resultados;
            private static Constantes constantes = new Constantes();

            public Jugador(string nombre)
            {
                this.nombre = nombre;
                dinero = constantes.DINERO_INICIAL;
                porrasGanadas = 0;
                resultados = new string[constantes.Num_Partidos];
                ReiniciarResultados();
            }

            public void ReiniciarResultados()
            {
                for (int i = 0; i < resultados.Length; i++)
                {
                    resultados[i] = "";
                }
            }

            public bool PuedePagar()
            {
                return dinero >= constantes.DINERO_CADA_JORNADA;
            }

            public void PonerEnElBote()
            {
                dinero -= constantes.DINERO_CADA_JORNADA;
                Console.WriteLine($"El jugador {nombre} aposto {constantes.DINERO_CADA_JORNADA} euros y le queda {dinero} euros");
            }

            public void GanarBote(double bote)
            {
                dinero += bote;
                porrasGanadas++;
                Console.WriteLine($"el jugador {nombre} gano {bote} euro/s y tiene {dinero} euros");
            }

            public void GenerarResultados()
            {
                int pLocal, pVisitante;
                Random random = new Random();

                for (int i = 0; i < resultados.Length; i++)
                {
                    pLocal = random.Next(constantes.RESULTADO_MINIMO, constantes.RESULTADO_MAXIMO + 1);
                    pVisitante = random.Next(constantes.RESULTADO_MINIMO, constantes.RESULTADO_MAXIMO + 1);
                    resultados[i] = $"{pLocal} - {pVisitante}";
                    Console.WriteLine($"El jugador {nombre} eligio {resultados[i]}");
                }
                Console.WriteLine("");
            }

            public bool HaAcertadoPorra(string[] resultadosPartidos)
            {
                for (int i = 0; i < resultados.Length; i++)
                {
                    if (!resultados[i].Equals(resultadosPartidos[i]))
                    {
                        return false;
                    }
                }
                return true;
            }

            public override string ToString()
            {
                return $"El jugador {nombre} tiene = {dinero} gano {porrasGanadas} porras";
            }
        }

        public class Metodos
        {
            public static int GeneraNumeroAleatorio(int minimo, int maximo)
            {
                Random random = new Random();
                return random.Next(minimo, maximo + 1);
            }
        }

        public class Porra
        {
            private double bote;
            private static Constantes constantes = new Constantes();
            private Jugador[] jugadores;

            public Porra()
            {
                bote = 0;
                jugadores = new Jugador[]
                {
                new Jugador("Cordelius"),
                new Jugador("Lily"),
                new Jugador("Surge"),
                new Jugador("Max"),
                new Jugador("Darryl"),
                new Jugador("Rico"),
                new Jugador("Rosa"),
                new Jugador("Primo"),
                new Jugador("Chester"),
                new Jugador("Spike"),
                new Jugador("Lola"),
                new Jugador("Squeak"),
                new Jugador("Tick"),
                new Jugador("Dinamike")
                };
            }

            public void AumentarBote(double dinero)
            {
                bote += dinero;
            }

            public void VaciarBote()
            {
                bote = 0;
            }

            public void Jornadas()
            {
                Resultados resultados = new Resultados();
                string[] partidos;

                for (int i = 0; i < constantes.NUMERO_JORNADAS; i++)
                {
                    Console.WriteLine($"JORNADA {i + 1}\n");

                    foreach (Jugador jugador in jugadores)
                    {
                        if (jugador.PuedePagar())
                        {
                            jugador.PonerEnElBote();
                            jugador.GenerarResultados();
                            AumentarBote(constantes.DINERO_CADA_JORNADA);
                        }
                        else
                        {
                            jugador.ReiniciarResultados();
                        }
                    }

                    resultados.GenerarResultados();
                    partidos = resultados.GetPartidos();

                    foreach (Jugador jugador in jugadores)
                    {
                        if (jugador.HaAcertadoPorra(partidos))
                        {
                            jugador.GanarBote(bote);
                            VaciarBote();
                        }
                    }

                    Console.WriteLine("\n" + ToString() + "\n");
                }

                foreach (Jugador jugador in jugadores)
                {
                    Console.WriteLine(jugador);
                }
            }

            public override string ToString()
            {
                return $"En la porra hay de bote {bote} euros";
            }
        }

        public class Resultados
        {
            private string[] partidos;
            private static Constantes constantes = new Constantes();

            public Resultados()
            {
                partidos = new string[constantes.Num_Partidos];
            }

            public void GenerarResultados()
            {
                int pLocal, pVisitante;
                Random random = new Random();

                for (int i = 0; i < partidos.Length; i++)
                {
                    pLocal = random.Next(constantes.RESULTADO_MINIMO, constantes.RESULTADO_MAXIMO + 1);
                    pVisitante = random.Next(constantes.RESULTADO_MINIMO, constantes.RESULTADO_MAXIMO + 1);
                    partidos[i] = $"{pLocal} - {pVisitante}";
                    Console.WriteLine($"El partido {i + 1} tiene el siguiente resultado: {partidos[i]}");
                }
            }

            public string[] GetPartidos()
            {
                return partidos;
            }
        }

        public class Ejer_obl_11
        {
            static void Main(string[] args)
            {
                Porra porra = new Porra();
                porra.Jornadas();

            Console.ReadKey();
            }
        }

    }

