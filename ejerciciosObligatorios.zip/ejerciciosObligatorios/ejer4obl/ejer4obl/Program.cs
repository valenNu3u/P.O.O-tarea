﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer4obl
{
    public class Electrodomestico
    {
        // Las constantes definidas
        protected const string COLOR_DEF = "blanco";
        protected const char CONSUMO_ENERGETICO_DEF = 'F';
        protected const double PRECIO_BASE_DEF = 100;
        protected const double PESO_DEF = 5;

        // Los atributos
        protected double precioBase;
        protected string color;
        protected char consumoEnergetico;
        protected double peso;

        // estos metodos son privados 
        private void ComprobarColor(string color)
        {
            string[] colores = { "blanco", "negro", "rojo", "azul", "gris" };
            bool encontrado = false;

            foreach (string col in colores)
            {
                if (col == color)
                {
                    encontrado = true;
                    break;
                }
            }

            if (encontrado)
            {
                this.color = color;
            }
            else
            {
                this.color = COLOR_DEF;
            }
        }

        private void ComprobarConsumoEnergetico(char consumoEnergetico)
        {
            if (consumoEnergetico >= 'A' && consumoEnergetico <= 'F')
            {
                this.consumoEnergetico = consumoEnergetico;
            }
            else
            {
                this.consumoEnergetico = CONSUMO_ENERGETICO_DEF;
            }
        }

        // Metodos get
        public double GetPrecioBase() => precioBase;
        public string GetColor() => color;
        public char GetConsumoEnergetico() => consumoEnergetico;
        public double GetPeso() => peso;

        // Metodo precioFinal, con estructura switch 
        public double PrecioFinal()
        {
            double costoAdicional = 0;

            switch (consumoEnergetico)
            {
                case 'A': costoAdicional += 100; break;
                case 'B': costoAdicional += 80; break;
                case 'C': costoAdicional += 60; break;
                case 'D': costoAdicional += 50; break;
                case 'E': costoAdicional += 30; break;
                case 'F': costoAdicional += 10; break;
            }

            if (peso >= 0 && peso < 20)
            {
                costoAdicional += 10;
            }
            else if (peso >= 20 && peso < 50)
            {
                costoAdicional += 50;
            }
            else if (peso >= 50 && peso < 80)
            {
                costoAdicional += 80;
            }
            else if (peso >= 80)
            {
                costoAdicional += 100;
            }

            return precioBase + costoAdicional;
        }

        // Constructores
        public Electrodomestico() : this(PRECIO_BASE_DEF, PESO_DEF, CONSUMO_ENERGETICO_DEF, COLOR_DEF) { }

        public Electrodomestico(double precioBase, double peso) : this(precioBase, peso, CONSUMO_ENERGETICO_DEF, COLOR_DEF) { }

        public Electrodomestico(double precioBase, double peso, char consumoEnergetico, string color)
        {
            this.precioBase = precioBase;
            this.peso = peso;
            ComprobarConsumoEnergetico(consumoEnergetico);
            ComprobarColor(color);
        }
    }

    public class Lavadora : Electrodomestico
    {
        // Constante DEF
        private const int CARGA_DEF = 5;

        // el atributo
        private int carga;

        // Metodo get
        public int GetCarga() => carga;

        // Metodo precioFinal
        public new double PrecioFinal()
        {
            double plus = base.PrecioFinal();
            if (carga > 30)
            {
                plus += 50;
            }
            return plus;
        }

        // Constructores
        public Lavadora() : this(PRECIO_BASE_DEF, PESO_DEF, CONSUMO_ENERGETICO_DEF, COLOR_DEF, CARGA_DEF) { }

        public Lavadora(double precioBase, double peso) : this(precioBase, peso, CONSUMO_ENERGETICO_DEF, COLOR_DEF, CARGA_DEF) { }

        public Lavadora(double precioBase, double peso, char consumoEnergetico, string color, int carga) : base(precioBase, peso, consumoEnergetico, color)
        {
            this.carga = carga;
        }
    }

    public class Television : Electrodomestico
    {
        // Constantes DEF
        private const int RESOLUCION_DEF = 20;

        // los atributos
        private int resolucion;
        private bool sintonizadorTDT;

        // Metodos get
        public int GetResolucion() => resolucion;
        public bool GetSintonizadorTDT() => sintonizadorTDT;

        // Metodo precioFinal
        public new double PrecioFinal()
        {
            double plus = base.PrecioFinal();
            if (resolucion > 40)
            {
                plus += precioBase * 0.3;
            }
            if (sintonizadorTDT)
            {
                plus += 50;
            }
            return plus;
        }

        // Constructores
        public Television() : this(PRECIO_BASE_DEF, PESO_DEF, CONSUMO_ENERGETICO_DEF, COLOR_DEF, RESOLUCION_DEF, false) { }

        public Television(double precioBase, double peso) : this(precioBase, peso, CONSUMO_ENERGETICO_DEF, COLOR_DEF, RESOLUCION_DEF, false) { }

        public Television(double precioBase, double peso, char consumoEnergetico, string color, int resolucion, bool sintonizadorTDT)
            : base(precioBase, peso, consumoEnergetico, color)
        {
            this.resolucion = resolucion;
            this.sintonizadorTDT = sintonizadorTDT;
        }
    }

    public class ElectrodomesticosApp
    {
        public static void Main()
        {
            Electrodomestico[] listaElectrodomesticos = new Electrodomestico[10];

            listaElectrodomesticos[0] = new Electrodomestico(200, 60, 'C', "Verde");
            listaElectrodomesticos[1] = new Lavadora(150, 30);
            listaElectrodomesticos[2] = new Television(500, 80, 'E', "negro", 42, false);
            listaElectrodomesticos[3] = new Electrodomestico();
            listaElectrodomesticos[4] = new Electrodomestico(600, 20, 'D', "gris");
            listaElectrodomesticos[5] = new Lavadora(300, 40, 'Z', "blanco", 40);
            listaElectrodomesticos[6] = new Television(250, 70);
            listaElectrodomesticos[7] = new Lavadora(400, 100, 'A', "verde", 15);
            listaElectrodomesticos[8] = new Television(200, 60, 'C', "naranja", 30, true);
            listaElectrodomesticos[9] = new Electrodomestico(50, 10);

            double sumaElectrodomesticos = 0;
            double sumaTelevisiones = 0;
            double sumaLavadoras = 0;

            foreach (var electrodomestico in listaElectrodomesticos)
            {
                sumaElectrodomesticos += electrodomestico.PrecioFinal();

                if (electrodomestico is Lavadora lavadora)
                {
                    sumaLavadoras += lavadora.PrecioFinal();
                }
                else if (electrodomestico is Television television)
                {
                    sumaTelevisiones += television.PrecioFinal();
                }
            }

            Console.WriteLine($"La suma del precio de los electrodomesticos es {sumaElectrodomesticos}");
            Console.WriteLine($"La suma del precio de las lavadoras es {sumaLavadoras}");
            Console.WriteLine($"La suma del precio de las televisiones es {sumaTelevisiones}");

            Console.ReadKey();
        }
    }
}

