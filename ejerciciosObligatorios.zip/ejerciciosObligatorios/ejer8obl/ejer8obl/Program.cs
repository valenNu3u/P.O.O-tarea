﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer8obl
{
    public abstract class Persona
    {
        // Atributos
        protected string nombre;
        protected char sexo;
        protected int edad;
        protected bool asistencia;

        protected static readonly string[] NOMBRES_CHICOS = { "Juan", "Carlos", "Kit", "Heist", "Rico", "Chester", "Larry" };
        protected static readonly string[] NOMBRES_CHICAS = { "Piper", "Bea", "Mandy", "Edgaria", "Melodie", "Lily", "Jessie" };

        private static readonly Random random = new Random(); // Generador de números aleatorios único

        public Persona()
        {
            int determinarSexo = random.Next(0, 2); 
            if (determinarSexo == 0)
            {
                nombre = NOMBRES_CHICOS[random.Next(0, NOMBRES_CHICOS.Length)];
                sexo = 'H';
            }
            else
            {
                nombre = NOMBRES_CHICAS[random.Next(0, NOMBRES_CHICAS.Length)];
                sexo = 'M';
            }
            Disponibilidad();
        }

        public string Nombre => nombre;
        public char Sexo => sexo;
        public int Edad { get => edad; set => edad = value; }
        public bool Asistencia { get => asistencia; set => asistencia = value; }

        public abstract void Disponibilidad();
    }

    public class Alumno : Persona
    {
        private int nota;

        public Alumno() : base()
        {
            nota = MetodoSueltos.GenerarNumAleatorio(0, 10);
            Edad = MetodoSueltos.GenerarNumAleatorio(12, 15);
        }

        public int Nota => nota;

        public override void Disponibilidad()
        {
            asistencia = MetodoSueltos.GenerarNumAleatorio(0, 100) >= 50;
        }

        public override string ToString()
        {
            return $"Nombre: {Nombre}, sexo: {Sexo}, nota: {nota}";
        }
    }

    public class Profesor : Persona
    {
        private string materia;

        public Profesor() : base()
        {
            Edad = MetodoSueltos.GenerarNumAleatorio(25, 50);
            materia = Constantes.MATERIAS[MetodoSueltos.GenerarNumAleatorio(0, Constantes.MATERIAS.Length - 1)];
        }

        public string Materia => materia;

        public override void Disponibilidad()
        {
            asistencia = MetodoSueltos.GenerarNumAleatorio(0, 100) >= 20;
        }
    }

    public class Aula
    {
        private int id = 1;
        private Profesor profesor = new Profesor();
        private Alumno[] alumnos;
        private string materia;
        private const int MAX_ALUMNOS = 20;

        public Aula()
        {
            alumnos = new Alumno[MAX_ALUMNOS];
            CrearAlumnos();
            materia = Constantes.MATERIAS[MetodoSueltos.GenerarNumAleatorio(0, Constantes.MATERIAS.Length - 1)];
        }

        private void CrearAlumnos()
        {
            for (int i = 0; i < alumnos.Length; i++)
            {
                alumnos[i] = new Alumno();
            }
        }

        private bool AsistenciaAlumnos()
        {
            int cuentaAsistencias = 0;
            foreach (var alumno in alumnos)
            {
                if (alumno.Asistencia)
                {
                    cuentaAsistencias++;
                }
            }
            return cuentaAsistencias >= (alumnos.Length / 2);
        }

        public bool DarClase()
        {
            string razon = null;

            if (!profesor.Asistencia)
            {
                razon = "El profesor no se encuentra, no es posible dar clase";
            }
            else if (profesor.Materia != materia)
            {
                razon = "La materia del profesor y del aula no coinciden, no es posible dar clase";
            }
            else if (!AsistenciaAlumnos())
            {
                razon = "La asistencia de alumnos no es suficiente, no es posible dar clase";
            }

            if (razon != null)
            {
                Console.WriteLine(razon);
                return false;
            }
            else
            {
                Console.WriteLine("Se puede dar clase");
                return true;
            }
        }

        public void Notas()
        {
            int chicosApro = 0, chicasApro = 0;
            foreach (var alumno in alumnos)
            {
                if (alumno.Nota >= 5)
                {
                    if (alumno.Sexo == 'H')
                        chicosApro++;
                    else
                        chicasApro++;

                    Console.WriteLine(alumno);
                }
            }
            Console.WriteLine($"Hay {chicosApro} chicos y {chicasApro} chicas aprobados");
        }
    }

    public static class Constantes
    {
        public static readonly string[] MATERIAS = { "Matematicas", "Filosofia", "Fisica" };
    }

    public static class MetodoSueltos
    {
        private static readonly Random random = new Random();

        public static int GenerarNumAleatorio(int minimo, int maximo)
        {
            return random.Next(minimo, maximo + 1);
        }
    }

    public class Principal
    {
        public static void Main()
        {
            Aula aula = new Aula();

            if (aula.DarClase())
            {
                aula.Notas();
            }
            Console.ReadKey();
        }
    }
}