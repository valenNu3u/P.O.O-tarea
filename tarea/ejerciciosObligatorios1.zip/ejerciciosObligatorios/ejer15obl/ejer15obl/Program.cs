﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer15obl
{
    public class Bebida
    {
        public int Id { get; set; }
        public double Litros { get; set; }
        public double Precio { get; set; }
        public string Marca { get; set; }

        public Bebida(int id, double litros, double precio, string marca)
        {
            Id = id;
            Litros = litros;
            Precio = precio;
            Marca = marca;
        }

        public virtual double ObtenerPrecio()
        {
            return Precio;
        }

        public virtual void MostrarInfo()
        {
            Console.WriteLine($"ID: {Id}, Marca: {Marca}, Litros: {Litros}, Precio: {Precio}");
        }
    }

    public class AguaMineral : Bebida
    {
        public string Origen { get; set; }

        public AguaMineral(int id, double litros, double precio, string marca, string origen)
            : base(id, litros, precio, marca)
        {
            Origen = origen;
        }

        public override void MostrarInfo()
        {
            Console.WriteLine($"ID: {Id}, Marca: {Marca}, Litros: {Litros}, Precio: {Precio}, Origen: {Origen}");
        }
    }

    public class BebidaAzucarada : Bebida
    {
        public double PorcentajeAzucar { get; set; }
        public bool TienePromocion { get; set; }

        public BebidaAzucarada(int id, double litros, double precio, string marca, double porcentajeAzucar, bool tienePromocion)
            : base(id, litros, precio, marca)
        {
            PorcentajeAzucar = porcentajeAzucar;
            TienePromocion = tienePromocion;
        }

        public override double ObtenerPrecio()
        {
            if (TienePromocion)
            {
                return Precio * 0.9; // 10%
            }
            return Precio;
        }

        public override void MostrarInfo()
        {
            Console.WriteLine($"ID: {Id}, Marca: {Marca}, Litros: {Litros}, Precio: {ObtenerPrecio()}, Azucar: {PorcentajeAzucar}%, Promocion: {TienePromocion}");
        }
    }

    public class Almacen
    {
        private Bebida[,] estanterias;
        private int filas = 2;
        private int columnas = 3;

        public Almacen()
        {
            estanterias = new Bebida[filas, columnas];
        }

        public void AgregarProducto(Bebida bebida)
        {
            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (estanterias[i, j] == null)
                    {
                        estanterias[i, j] = bebida;
                        Console.WriteLine("Producto agregado");
                        return;
                    }
                    else if (estanterias[i, j].Id == bebida.Id)
                    {
                        Console.WriteLine("El ID ya existe");
                        return;
                    }
                }
            }
            Console.WriteLine("No hay espacio en el almacen");
        }

        public void EliminarProducto(int id)
        {
            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (estanterias[i, j] != null && estanterias[i, j].Id == id)
                    {
                        estanterias[i, j] = null;
                        Console.WriteLine("Producto eliminado.");
                        return;
                    }
                }
            }
            Console.WriteLine("No se encontro el producto con ese ID.");
        }

        public double CalcularPrecioTotal()
        {
            double total = 0;
            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (estanterias[i, j] != null)
                    {
                        total += estanterias[i, j].ObtenerPrecio();
                    }
                }
            }
            return total;
        }

        public double CalcularPrecioPorMarca(string marca)
        {
            double total = 0;
            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (estanterias[i, j] != null && estanterias[i, j].Marca == marca)
                    {
                        total += estanterias[i, j].ObtenerPrecio();
                    }
                }
            }
            return total;
        }

        public double CalcularPrecioPorEstanteria(int columna)
        {
            if (columna < 0 || columna >= columnas)
            {
                Console.WriteLine("El numero de estanteria no es valido.");
                return 0;
            }

            double total = 0;
            for (int i = 0; i < filas; i++)
            {
                if (estanterias[i, columna] != null)
                {
                    total += estanterias[i, columna].ObtenerPrecio();
                }
            }
            return total;
        }
        public void MostrarInformacion()
        {
            Console.WriteLine("Informacion del almacen:");
            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (estanterias[i, j] != null)
                    {
                        estanterias[i, j].MostrarInfo();
                    }
                    else
                    {
                        Console.WriteLine($"Espacio vacio en fila {i + 1}, columna {j + 1}");
                    }
                }
            }
        }
    }

    class Program
    {
        static void Main()
        {
            Almacen almacen = new Almacen();

            Bebida agua1 = new AguaMineral(1, 1.5, 0.80, "Villavisencio", "Glaciar");
            Bebida azucarada1 = new BebidaAzucarada(2, 2.0, 1.50, "Coca-Cola", 10, true);
            Bebida azucarada2 = new BebidaAzucarada(3, 2.0, 1.50, "Pepsi", 9, false);

            almacen.AgregarProducto(agua1);
            almacen.AgregarProducto(azucarada1);
            almacen.AgregarProducto(azucarada2);

            almacen.MostrarInformacion();

            Console.WriteLine($"Precio total de todas las bebidas: {almacen.CalcularPrecioTotal()}");
            Console.WriteLine($"Precio total de la marca Coca-Cola: {almacen.CalcularPrecioPorMarca("Coca-Cola")}");
            Console.WriteLine($"Precio total de la estanteria 1: {almacen.CalcularPrecioPorEstanteria(0)}");

            almacen.EliminarProducto(2);
            almacen.MostrarInformacion();
            Console.ReadKey();
        }
    }
}
