﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer5obl
{
    public interface IEntregable
    {
        void Entregar();
        void Devolver();
        bool IsEntregado();
    }

    public class Serie : IEntregable
    {
        public string Titulo { get; set; }
        public int NumeroTemporadas { get; set; } = 3;
        public string Genero { get; set; }
        public string Creador { get; set; }

        private bool entregado = false;

        public Serie(string titulo, string creador)
        {
            Titulo = titulo;
            Creador = creador;
        }

        public Serie(string titulo, int numeroTemporadas, string genero, string creador)
        {
            Titulo = titulo;
            NumeroTemporadas = numeroTemporadas;
            Genero = genero;
            Creador = creador;
        }

        public void Entregar() => entregado = true;
        public void Devolver() => entregado = false;
        public bool IsEntregado() => entregado;

        public int CompareTo(Serie otraSerie) => NumeroTemporadas.CompareTo(otraSerie.NumeroTemporadas);

        public void MostrarInfo()
        {
            Console.WriteLine($"Titulo: {Titulo}, Temporadas: {NumeroTemporadas}, Genero: {Genero}, Creador: {Creador}, Entregado: {entregado}");
        }
    }

    public class Videojuego : IEntregable
    {
        public string Titulo { get; set; }
        public int HorasEstimadas { get; set; } = 10;
        public string Genero { get; set; }
        public string Compania { get; set; }
        private bool entregado = false;

        public Videojuego() { }

        public Videojuego(string titulo, int horasEstimadas)
        {
            Titulo = titulo;
            HorasEstimadas = horasEstimadas;
        }

        public Videojuego(string titulo, int horasEstimadas, string genero, string compania)
        {
            Titulo = titulo;
            HorasEstimadas = horasEstimadas;
            Genero = genero;
            Compania = compania;
        }

        public void Entregar() => entregado = true;
        public void Devolver() => entregado = false;
        public bool IsEntregado() => entregado;

        public int CompareTo(Videojuego otroVideojuego) => HorasEstimadas.CompareTo(otroVideojuego.HorasEstimadas);

        public void MostrarInfo()
        {
            Console.WriteLine($"Título: {Titulo}, Horas: {HorasEstimadas}, Género: {Genero}, Compañía: {Compania}, Entregado: {entregado}");
        }
    }

    class Program
    {
        static void Main()
        {
            Serie[] series = new Serie[5];
            Videojuego[] videojuegos = new Videojuego[5];

            series[0] = new Serie("Murder Drones", "Liam Vickers");
            series[1] = new Serie("Belleza verdadera", "Studio Dragon");
            series[2] = new Serie("Fnaf High School", 5, "Drama", "Edoochan");
            series[3] = new Serie("Cliffside", 2, "Comedia", "Liam Vickers");
            series[4] = new Serie("Digital Circus", 4, "Drama Psicologico", "Gooseworx");

            videojuegos[0] = new Videojuego("Brawl Stars", 79);
            videojuegos[1] = new Videojuego("Rhythm Heaven Fever", 15);
            videojuegos[2] = new Videojuego("Friday Night Funkin'", 12, "Juego musical", "Newgrounds, NinjaMuffin99");
            videojuegos[3] = new Videojuego("The Last of Us", 20, "Aventura", "Neil Druckmann, Bruce Straley");
            videojuegos[4] = new Videojuego("Cuphead", 10, "Run and Gun", "Studio MDHR");

            series[1].Entregar();
            series[3].Entregar();
            videojuegos[0].Entregar();
            videojuegos[2].Entregar();
            videojuegos[4].Entregar();

            int seriesEntregadas = 0, videojuegosEntregados = 0;

            foreach (var serie in series)
            {
                if (serie.IsEntregado())
                {
                    seriesEntregadas++;
                    serie.Devolver();
                }
            }

            foreach (var videojuego in videojuegos)
            {
                if (videojuego.IsEntregado())
                {
                    videojuegosEntregados++;
                    videojuego.Devolver();
                }
            }

            Console.WriteLine($"Series entregadas: {seriesEntregadas}");
            Console.WriteLine($"Videojuegos entregados: {videojuegosEntregados}");

            Serie serieMayor = series[0];
            Videojuego videojuegoMayor = videojuegos[0];

            foreach (var serie in series)
            {
                if (serie.NumeroTemporadas > serieMayor.NumeroTemporadas)
                    serieMayor = serie;
            }

            foreach (var videojuego in videojuegos)
            {
                if (videojuego.HorasEstimadas > videojuegoMayor.HorasEstimadas)
                    videojuegoMayor = videojuego;
            }

            Console.WriteLine("Serie con mas temporadas:");
            serieMayor.MostrarInfo();

            Console.WriteLine("Videojuego con mas horas estimadas:");
            videojuegoMayor.MostrarInfo();

            Console.ReadKey();
        }
    }
}
