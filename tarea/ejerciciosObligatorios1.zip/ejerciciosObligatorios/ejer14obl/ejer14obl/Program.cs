﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer14obl
{
    public class Producto
    {
        protected string Nombre;
        protected double Precio;

        public Producto(string nombre, double precio)
        {
            Nombre = nombre;
            Precio = precio;
        }
        public virtual double Calcular(int cantidad)
        {
            return Precio * cantidad;
        }
        public virtual void MostrarInfo()
        {
            Console.WriteLine($"Nombre: {Nombre}, Precio: {Precio}");
        }
    }

    public class Perecedero : Producto
    {
        private int DiasACaducar;

        public Perecedero(string nombre, double precio, int diasACaducar)
            : base(nombre, precio)
        {
            DiasACaducar = diasACaducar;
        }

        public override double Calcular(int cantidad)
        {
            double precioFinal = base.Calcular(cantidad);

            if (DiasACaducar == 1)
            {
                precioFinal /= 4;
            }
            else if (DiasACaducar == 2)
            {
                precioFinal /= 3;
            }
            else if (DiasACaducar == 3)
            {
                precioFinal /= 2;
            }

            return precioFinal;
        }

        public override void MostrarInfo()
        {
            Console.WriteLine($"Nombre: {Nombre}, Precio: {Precio} , Dias a caducar: {DiasACaducar}");
        }
    }
    public class NoPerecedero : Producto
    {
        private string Tipo;
        public NoPerecedero(string nombre, double precio, string tipo)
            : base(nombre, precio)
        {
            Tipo = tipo;
        }
        public override void MostrarInfo()
        {
            Console.WriteLine($"Nombre: {Nombre}, Precio: {Precio}€, Tipo: {Tipo}");
        }
    }

    class Program
    {
        static void Main()
        {
            Producto[] productos = new Producto[3];

            productos[0] = new Producto("Galletas", 1.500);
            productos[1] = new Perecedero("Leche", 2.000, 2);
            productos[2] = new NoPerecedero("Lata de atun", 3.000, "Conserva");

            int cantidad = 5;

            Console.WriteLine("Informacion de los productos y precio al comprar 5 unidades:\n");

            foreach (Producto p in productos)
            {
                p.MostrarInfo();
                Console.WriteLine($"Precio total por {cantidad} unidades: {p.Calcular(cantidad)}\n");
            }
            Console.ReadKey();
        }
    }
}
