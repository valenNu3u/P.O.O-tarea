﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer8obl
{
    public class Persona
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }
        public string Sexo { get; set; }

        public Persona(string nombre, int edad, string sexo)
        {
            Nombre = nombre;
            Edad = edad;
            Sexo = sexo;
        }
    }

    public class Estudiante : Persona
    {
        public double Calificacion { get; set; }
        public bool AsisteClase { get; set; }

        public Estudiante(string nombre, int edad, string sexo, double calificacion) : base(nombre, edad, sexo)
        {
            Calificacion = calificacion;
            AsisteClase = false;  
        }

        public void Faltar()
        {
            AsisteClase = false;
        }

        public void Asistir()
        {
            AsisteClase = true;
        }
    }

    public class Profesor : Persona
    {
        public string Materia { get; set; }
        public bool EstaDisponible { get; set; }

        public Profesor(string nombre, int edad, string sexo, string materia) : base(nombre, edad, sexo)
        {
            Materia = materia;
            EstaDisponible = true;
        }

        public void NoEstarDisponible()
        {
            EstaDisponible = false;
        }

        public void EstarDisponible()
        {
            EstaDisponible = true;
        }
    }

    public class Aula
    {
        public int Id { get; set; }
        public int MaxEstudiantes { get; set; }
        public string Materia { get; set; }
        public List<Estudiante> Estudiantes { get; set; }
        public Profesor Profesor { get; set; }

        public Aula(int id, int maxEstudiantes, string materia, Profesor profesor)
        {
            Id = id;
            MaxEstudiantes = maxEstudiantes;
            Materia = materia;
            Profesor = profesor;
            Estudiantes = new List<Estudiante>();
        }

        public bool PuedeDarClase()
        {
            if (Profesor.EstaDisponible == false || Profesor.Materia != Materia)
            {
                return false;
            }

            int estudiantesPresentes = 0;
            foreach (var estudiante in Estudiantes)
            {
                if (estudiante.AsisteClase) estudiantesPresentes++;
            }

            if (estudiantesPresentes > MaxEstudiantes / 2)
            {
                return true;
            }

            return false;
        }

        public void MostrarResultados()
        {
            if (PuedeDarClase())
            {
                int aprobados = 0, reprobados = 0;
                foreach (var estudiante in Estudiantes)
                {
                    if (estudiante.Calificacion >= 6) aprobados++;
                    else reprobados++;
                }
                Console.WriteLine($"Clase realizada. Aprobados: {aprobados}, Reprobados: {reprobados}");
            }
            else
            {
                Console.WriteLine("No se puede dar clase.");
            }
        }
    }

    public class Program
    {
        public static void Main()
        {
            Profesor profesor = new Profesor("Juan", 40, "Masculino", "Matematicas");

            Aula aula = new Aula(101, 30, "Matematicas", profesor);

            Estudiante estudiante1 = new Estudiante("Carlos", 20, "Masculino", 8);
            Estudiante estudiante2 = new Estudiante("Maria", 22, "Femenino", 5);
            Estudiante estudiante3 = new Estudiante("Ana", 21, "Femenino", 7);

            aula.Estudiantes.Add(estudiante1);
            aula.Estudiantes.Add(estudiante2);
            aula.Estudiantes.Add(estudiante3);

            estudiante1.Asistir();
            estudiante2.Faltar();
            estudiante3.Asistir();

            aula.MostrarResultados();
        }
    }
}