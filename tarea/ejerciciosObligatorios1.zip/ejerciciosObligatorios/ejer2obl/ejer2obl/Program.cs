﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer2obl
{
    public class Persona
    {
        private string nombre;
        private int edad;
        private string dni;
        private char sexo;
        private double peso;
        private double altura;

        private const char SexoDefecto = 'H';
        private const int PesoIdeal = 0;
        private const int Sobrepeso = 1;
        private const int MuyFlaco = -1;

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public int Edad
        {
            get { return edad; }
            set { edad = value; }
        }

        public string DNI
        {
            get { return dni; }
        }

        public char Sexo
        {
            get { return sexo; }
            set { sexo = ComprobarSexo(value); } // verifico si es hombre o mujer
        }

        public double Peso
        {
            get { return peso; }
            set { peso = value; }
        }

        public double Altura
        {
            get { return altura; }
            set { altura = value; }
        }

        public Persona()
        {
            this.nombre = "";
            this.edad = 0;
            this.sexo = SexoDefecto;
            this.peso = 0;
            this.altura = 0;
            this.dni = GenerarDNI();
        }
        public Persona(string nombre, int edad, char sexo)
        {
            this.nombre = nombre;
            this.edad = edad;
            this.sexo = ComprobarSexo(sexo);
            this.peso = 0;
            this.altura = 0;
            this.dni = GenerarDNI();
        }
        public Persona(string nombre, int edad, char sexo, double peso, double altura)
        {
            this.nombre = nombre;
            this.edad = edad;
            this.sexo = ComprobarSexo(sexo);
            this.peso = peso;
            this.altura = altura;
            this.dni = GenerarDNI();
        }
        public int CalcularIMC()
        {
            if (altura <= 0) return PesoIdeal;

            double imc = peso / (altura * altura);

            if (imc <= 20) return MuyFlaco;
            if (imc <= 25) return PesoIdeal;
            return Sobrepeso;
        }

        public bool EsMayor()
        {
            return edad >= 18;
        }

        private char ComprobarSexo(char sexo)
        {
            return (sexo == 'H' || sexo == 'M') ? sexo : SexoDefecto;
        }

        private string GenerarDNI()
        {
            return "47308971"; 
        }
        public string MostrarInfo()
        {
            return $"Nombre: {nombre}, Edad: {edad}, DNI: {dni}, Sexo: {sexo}, Peso: {peso} kg, Altura: {altura} m";
        }
    }

    class Program
    {
        static void Main()
        {
            Console.Write("Ingrese el nombre: ");
            string nombre = Console.ReadLine();

            Console.Write("Ingrese la edad: ");
            int edad = int.Parse(Console.ReadLine());

            Console.Write("Ingrese sexo (H/M): ");
            char sexo = Console.ReadLine()[0];

            Console.Write("Ingrese peso (kg): ");
            double peso = double.Parse(Console.ReadLine());

            Console.Write("Ingrese altura (m): ");
            double altura = double.Parse(Console.ReadLine());

            Persona persona1 = new Persona(nombre, edad, sexo, peso, altura);
            Persona persona2 = new Persona(nombre, edad, sexo);
            Persona persona3 = new Persona();
            persona3.Nombre = "Carlos";
            persona3.Edad = 25;
            persona3.Sexo = 'M';
            persona3.Peso = 80;
            persona3.Altura = 1.75;

            EvaluarPersona(persona1);
            EvaluarPersona(persona2);
            EvaluarPersona(persona3);

            Console.ReadKey();
        }

        static void EvaluarPersona(Persona persona)
        {
            Console.WriteLine(persona.MostrarInfo());

            int imc = persona.CalcularIMC();
            if (imc == -1)
                Console.WriteLine("Esta por debajo del peso ideal.");
            else if (imc == 0)
                Console.WriteLine("Esta en su peso ideal.");
            else
                Console.WriteLine("Tiene sobrepeso.");

            Console.WriteLine(persona.EsMayor() ? "Es mayor de edad." : "Es menor de edad.");
            Console.WriteLine();
        }
    }
}