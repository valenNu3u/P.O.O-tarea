﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ejer1obl
{
    public class Cuenta
    {
        private string titular;
        private double cantidad;

        public Cuenta(string titular)
        {
            this.titular = titular;
        }

        public Cuenta(string titular, double cantidad)
        {
            this.titular = titular;
            this.cantidad = cantidad > 0 ? cantidad : 0;
        }

        public string Titular
        {
            get { return titular; }
            set { titular = value; }
        }

        public double Cantidad
        {
            get { return cantidad; }
        }

        public void Ingresar(double cantidad)
        {
            if (cantidad > 0)
            {
                this.cantidad += cantidad;
            }
        }

        public void Retirar(double cantidad)
        {
            if (this.cantidad - cantidad < 0)
            {
                this.cantidad = 0;
            }
            else
            {
                this.cantidad -= cantidad;
            }
        }

        public override string ToString()
        {
            return $"Titular: {titular}, Cantidad: {cantidad}";
        }
        static void Main(string[] args)
        {
            Cuenta cuenta1 = new Cuenta("Pedrito");
            Console.WriteLine(cuenta1);

            cuenta1.Ingresar(300);
            Console.WriteLine($"Luego de ingresar 300: {cuenta1} ");

            cuenta1.Retirar(50);
            Console.WriteLine($"Luego de retirar 50: {cuenta1} ");

            cuenta1.Retirar(200);
            Console.WriteLine($"Luego de retirar 200: {cuenta1}");

            Cuenta cuenta2 = new Cuenta("Adriana", 500);
            Console.WriteLine(cuenta2);

            cuenta2.Ingresar(-100);
            Console.WriteLine($"Luego de ingresar un valor negativo: {cuenta2}");

            cuenta2.Retirar(500);
            Console.WriteLine($"Luego de retirar 500: {cuenta2}");
            Console.ReadKey();
        }
    }
}