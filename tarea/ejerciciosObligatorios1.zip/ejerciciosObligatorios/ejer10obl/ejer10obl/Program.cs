﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer10obl
{ 
    public class Carta
    {
        public int Numero { get; set; }
        public string Palo { get; set; }

        public Carta(int numero, string palo)
        {
            Numero = numero;
            Palo = palo;
        }

        public void MostrarInfo()
        {
            Console.WriteLine($"{Numero} de {Palo}");
        }
    }

    public class Baraja
    {
        private List<Carta> cartas;
        private List<Carta> cartasSalen;

        public Baraja()
        {
            cartas = new List<Carta>();
            cartasSalen = new List<Carta>();

            string[] palos = { "Espadas", "Bastos", "Oros", "Copas" };
            foreach (string palo in palos)
            {
                for (int i = 1; i <= 12; i++)
                {
                    if (i != 8 && i != 9)
                    {
                        cartas.Add(new Carta(i, palo));
                    }
                }
            }
        }

        public Carta SiguienteCarta()
        {
            if (cartas.Count == 0)
            {
                Console.WriteLine("No hay mas cartas.");
                return null;
            }

            Carta carta = cartas[0];
            cartas.RemoveAt(0); 
            cartasSalen.Add(carta); 
            return carta;
        }

       
        public int CartasDisponibles()
        {
            return cartas.Count;
        }
        public List<Carta> DarCartas(int cantidad)
        {
            if (cantidad > cartas.Count)
            {
                Console.WriteLine("No hay suficientes cartas.");
                return new List<Carta>(); 
            }

            List<Carta> cartasPedidas = new List<Carta>();

            for (int i = 0; i < cantidad; i++)
            {
                cartasPedidas.Add(SiguienteCarta()); 
            }

            return cartasPedidas;
        }

        public void CartasMonton()
        {
            if (cartasSalen.Count == 0)
            {
                Console.WriteLine("No ha salido ninguna carta todavia.");
            }
            else
            {
                Console.WriteLine("Cartas que han salido:");
                foreach (Carta carta in cartasSalen)
                {
                    carta.MostrarInfo();
                }
            }
        }
        public void MostrarBaraja()
        {
            if (cartas.Count == 0)
            {
                Console.WriteLine("La baraja esta vacia.");
            }
            else
            {
                Console.WriteLine("Cartas que quedan en la baraja:");
                foreach (Carta carta in cartas)
                {
                    carta.MostrarInfo(); 
                }
            }
        }
    }

    public class Program
    {
        public static void Main()
        {
            Baraja baraja = new Baraja();

            Console.WriteLine("Baraja inicial:");
            baraja.MostrarBaraja();

            Console.WriteLine("\nSiguiente carta: ");
            baraja.SiguienteCarta().MostrarInfo();

            baraja.CartasMonton();

            Console.WriteLine("\nCartas disponibles: " + baraja.CartasDisponibles());

            Console.WriteLine("\nDar 3 cartas:");
            var cartasDadas = baraja.DarCartas(3);
            foreach (var carta in cartasDadas)
            {
                carta.MostrarInfo();
            }

            baraja.CartasMonton();

            Console.WriteLine("\nCartas restantes en la baraja:");
            baraja.MostrarBaraja();
            Console.ReadKey();
        }
    }
}