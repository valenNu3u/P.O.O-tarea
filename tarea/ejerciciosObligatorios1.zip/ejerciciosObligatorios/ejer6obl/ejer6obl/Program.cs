﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer6obl
{
    public class Libro
    {
        private string isbn;
        private string titulo;
        private string autor;
        private int numPaginas;

        public string ISBN
        {
            get { return isbn; }
            set { isbn = value; }
        }
        public string Titulo
        {
            get { return titulo; }
            set { titulo = value; }
        }
        public string Autor
        {
            get { return autor; }
            set { autor = value; }
        }
        public int NumPaginas
        {
            get { return numPaginas; }
            set { numPaginas = value; }
        }

        public Libro(string ISBN, string titulo, string autor, int numPaginas)
        {
            this.isbn = ISBN;
            this.titulo = titulo;
            this.autor = autor;
            this.numPaginas = numPaginas;
        }

        public void MostrarInfo()
        {
            Console.WriteLine($"El libro con ISBN {isbn}, titulado '{titulo}', creado por {autor}, tiene {numPaginas} paginas.");
        }
    }

    class Program
    {
        static void Main()
        {
            Libro libro1 = new Libro("123-4-56-678910-1", "El Aleph", "Jorge Luis Borges", 60);
            Libro libro2 = new Libro("112-13-1415-1617", "Irlandeses detrás de un gato", "Jorge Luis Borges", 100);

            libro1.MostrarInfo();
            libro2.MostrarInfo();

            if (libro1.NumPaginas > libro2.NumPaginas)
            {
                Console.WriteLine($"El libro con más paginas es: '{libro1.Titulo}' con {libro1.NumPaginas} paginas.");
            }
            else
            {
                Console.WriteLine($"El libro con más paginas es: '{libro2.Titulo}' con {libro2.NumPaginas} paginas.");
            }

            Console.ReadKey();
        }
    }
}
