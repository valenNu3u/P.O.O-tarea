﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer7obl
{
    public class Raices
    {
        private double a;
        private double b;
        private double c;

        public Raices(double a, double b, double c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }

        public double GetDiscriminante()
        {
            return (b * b) - (4 * a * c);
        }

        public bool TieneRaices()
        {
            return GetDiscriminante() > 0;
        }

        public bool TieneRaiz()
        {
            return GetDiscriminante() == 0;
        }

        public void ObtenerRaices()
        {
            if (TieneRaices())
            {
                double discriminante = Math.Sqrt(GetDiscriminante());
                double x1 = (-b + discriminante) / (2 * a);
                double x2 = (-b - discriminante) / (2 * a);
                Console.WriteLine($"Las soluciones de la ecuacion son: x1 = {x1}, x2 = {x2}");
            }
        }

        public void ObtenerRaiz()
        {
            if (TieneRaiz())
            {
                double x = -b / (2 * a);
                Console.WriteLine($"La única solución de la ecuación es: x = {x}");
            }
        }

        public void Calcular()
        {
            if (TieneRaices())
            {
                ObtenerRaices();
            }
            else if (TieneRaiz())
            {
                ObtenerRaiz();
            }
            else
            {
                Console.WriteLine("La ecuación no tiene solución real.");
            }
        }
    }

    class Program
    {
        static void Main()
        {
            Raices ecuacion = new Raices(1, -3, 2);
            ecuacion.Calcular();

            Console.ReadKey();
        }
    }
}