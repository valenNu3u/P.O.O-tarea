﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer16obl
{
    public class Contacto
    {
        public string Nombre { get; set; }
        public string Telefono { get; set; }

        public Contacto(string nombre, string telefono)
        {
            Nombre = nombre;
            Telefono = telefono;
        }
    }

    public class Agenda
    {
        private Contacto[] contactos;
        private int cantidadMaxima;

        public Agenda(int tamaño = 10) 
        {
            cantidadMaxima = tamaño;
            contactos = new Contacto[cantidadMaxima];
        }

        public void AniadirContacto(Contacto c)
        {
            if (AgendaLlena())
            {
                Console.WriteLine("La agenda esta llena, no es posible agregar mas contactos.");
                return;
            }

            if (ExisteContacto(c))
            {
                Console.WriteLine("Este contacto ya existe en la agenda.");
                return;
            }

            for (int i = 0; i < contactos.Length; i++)
            {
                if (contactos[i] == null)
                {
                    contactos[i] = c;
                    Console.WriteLine("Contacto agregado correctamente.");
                    return;
                }
            }
        }

        public bool ExisteContacto(Contacto c)
        {
            foreach (var contacto in contactos)
            {
                if (contacto != null && contacto.Nombre == c.Nombre)
                {
                    return true;
                }
            }
            return false;
        }

        public void ListarContactos()
        {
            Console.WriteLine("Lista de contactos:");
            foreach (var contacto in contactos)
            {
                if (contacto != null)
                {
                    Console.WriteLine($"Nombre: {contacto.Nombre}, Telefono: {contacto.Telefono}");
                }
            }
        }

        public void BuscarContacto(string nombre)
        {
            foreach (var contacto in contactos)
            {
                if (contacto != null && contacto.Nombre == nombre)
                {
                    Console.WriteLine($"Telefono de {nombre}: {contacto.Telefono}");
                    return;
                }
            }
            Console.WriteLine("Contacto no encontrado.");
        }

        public void EliminarContacto(string nombre)
        {
            for (int i = 0; i < contactos.Length; i++)
            {
                if (contactos[i] != null && contactos[i].Nombre == nombre)
                {
                    contactos[i] = null;
                    Console.WriteLine("Contacto eliminado correctamente.");
                    return;
                }
            }
            Console.WriteLine("No se encontro el contacto.");
        }

        public bool AgendaLlena()
        {
            foreach (var contacto in contactos)
            {
                if (contacto == null)
                {
                    return false;
                }
            }
            return true;
        }

        public int HuecosLibres()
        {
            int espacios = 0;
            foreach (var contacto in contactos)
            {
                if (contacto == null)
                {
                    espacios++;
                }
            }
            return espacios;
        }
    }

    class Program
    {
        static void Main()
        {
            Console.Write("Ingrese el tamaño de la agenda: ");
            int tamañoAgenda;
            if (!int.TryParse(Console.ReadLine(), out tamañoAgenda) || tamañoAgenda <= 0)
            {
                tamañoAgenda = 10; 
            }

            Agenda agenda = new Agenda(tamañoAgenda);
            int opcion;

            do
            {
                Console.WriteLine("\n--- MENU AGENDA ---");
                Console.WriteLine("1. Añadir contacto");
                Console.WriteLine("2. Buscar contacto");
                Console.WriteLine("3. Eliminar contacto");
                Console.WriteLine("4. Mostrar todos los contactos");
                Console.WriteLine("5. Verificar si la agenda esta llena");
                Console.WriteLine("6. Ver huecos disponibles");
                Console.WriteLine("7. Salir");
                Console.Write("Seleccionar una opcion: ");

                if (!int.TryParse(Console.ReadLine(), out opcion))
                {
                    Console.WriteLine("Por favor, ingrese un numero valido.");
                    continue;
                }

                switch (opcion)
                {
                    case 1:
                        Console.Write("Ingrese el nombre: ");
                        string nombre = Console.ReadLine();
                        Console.Write("Ingrese el telefono: ");
                        string telefono = Console.ReadLine();
                        agenda.AniadirContacto(new Contacto(nombre, telefono));
                        break;

                    case 2:
                        Console.Write("Ingrese el nombre del contacto a buscar: ");
                        string nombreBuscar = Console.ReadLine();
                        agenda.BuscarContacto(nombreBuscar);
                        break;

                    case 3:
                        Console.Write("Ingrese el nombre del contacto a eliminar: ");
                        string nombreEliminar = Console.ReadLine();
                        agenda.EliminarContacto(nombreEliminar);
                        break;

                    case 4:
                        agenda.ListarContactos();
                        break;

                    case 5:
                        Console.WriteLine(agenda.AgendaLlena() ? "La agenda esta llena." : "Todavia hay espacio disponible.");
                        break;

                    case 6:
                        Console.WriteLine($"Huecos libres: {agenda.HuecosLibres()}");
                        break;

                    case 7:
                        Console.WriteLine("Saliendo...");
                        break;

                    default:
                        Console.WriteLine("Esta opcion no es valida.");
                        break;
                }
            } while (opcion != 7);
        }
    }
}
