﻿using ejer11obl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer11obl
{
    public class Jugador
    {
        public string Nombre { get; set; }
        public double Dinero { get; set; }
        public int PartidosGanados { get; set; }

        public Jugador(string nombre, double dineroInicial)
        {
            Nombre = nombre;
            Dinero = dineroInicial;
            PartidosGanados = 0;
        }

        public void Apostar()
        {
            if (Dinero >= 1)
            {
                Dinero -= 1;
                Console.WriteLine($"{Nombre} ha apostado 1 euro.");
            }
            else
            {
                Console.WriteLine($"{Nombre} no tiene suficiente dinero para apostar.");
            }
        }

        public void Ganar(double cantidad)
        {
            Dinero += cantidad;
            PartidosGanados++;
            Console.WriteLine($"{Nombre} ha ganado {cantidad} euros.");
        }

        public void MostrarInfo()
        {
            Console.WriteLine($"Jugador: {Nombre} - Dinero: {Dinero} - Partidos ganados: {PartidosGanados}");
        }
    }
    public class Partido
    {
        public string Equipo1 { get; set; }
        public string Equipo2 { get; set; }
        public string Resultado { get; set; }

        public Partido(string equipo1, string equipo2)
        {
            Equipo1 = equipo1;
            Equipo2 = equipo2;
        }

        public void GenerarResultado()
        {
            Resultado = "1-1";
        }

        public void MostrarResultado()
        {
            Console.WriteLine($"{Equipo1} vs {Equipo2} - Resultado: {Resultado}");
        }
    }

    public class Apuesta
    {
        public List<Jugador> Jugadores { get; set; }
        public double Pozo { get; set; }

        public Apuesta()
        {
            Jugadores = new List<Jugador>();
            Pozo = 0;
        }

        public void RealizarApuesta(Jugador jugador)
        {
            jugador.Apostar();
            Pozo += 1;
        }

        public void ComprobarResultados(Partido partido)
        {
            foreach (var jugador in Jugadores)
            {
                if (partido.Resultado == "1-1")
                {
                    jugador.Ganar(Pozo);
                    Pozo = 0;
                    break;
                }
            }
        }
    }

    class Program
    {
        static void Main()
        {
            Jugador jugador1 = new Jugador("Juan", 10);
            Jugador jugador2 = new Jugador("Ana", 10);

            Apuesta apuesta = new Apuesta();

            apuesta.Jugadores.Add(jugador1);
            apuesta.Jugadores.Add(jugador2);

            apuesta.RealizarApuesta(jugador1);
            apuesta.RealizarApuesta(jugador2);

            Partido partido = new Partido("Equipo1", "Equipo2");
            partido.GenerarResultado();
            partido.MostrarResultado();

            apuesta.ComprobarResultados(partido);

            jugador1.MostrarInfo();
            jugador2.MostrarInfo();
        }
    }
}

