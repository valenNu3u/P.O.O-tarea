﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Pelicula
{
    public string Titulo { get; set; }
    public int Duracion { get; set; }
    public int EdadMinima { get; set; }
    public string Director { get; set; }

    public Pelicula(string titulo, int duracion, int edadMinima, string director)
    {
        Titulo = titulo;
        Duracion = duracion;
        EdadMinima = edadMinima;
        Director = director;
    }
}

public class Espectador
{
    public string Nombre { get; set; }
    public int Edad { get; set; }
    public double Dinero { get; set; }

    public Espectador(string nombre, int edad, double dinero)
    {
        Nombre = nombre;
        Edad = edad;
        Dinero = dinero;
    }

    public bool PuedeVerPelicula(Pelicula pelicula)
    {
        return Edad >= pelicula.EdadMinima;
    }

    public bool PuedePagar(double precioEntrada)
    {
        return Dinero >= precioEntrada;
    }
}

public class Cine
{
    private string[,] asientos;
    public Pelicula PeliculaActual { get; set; }
    public double PrecioEntrada { get; set; }

    public Cine(Pelicula peliculaActual, double precioEntrada)
    {
        this.PeliculaActual = peliculaActual;
        this.PrecioEntrada = precioEntrada;

        asientos = new string[8, 9];
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                asientos[i, j] = "Libre";
            }
        }
    }

    public bool SentarEspectador(Espectador espectador)
    {
        if (!espectador.PuedePagar(PrecioEntrada))
        {
            Console.WriteLine($"{espectador.Nombre} no tiene suficiente dinero.");
            return false;
        }
        if (!espectador.PuedeVerPelicula(PeliculaActual))
        {
            Console.WriteLine($"{espectador.Nombre} no tiene la edad suficiente para ver esta pelicula.");
            return false;
        }

        for (int fila = 7; fila >= 0; fila--)
        {
            for (int columna = 0; columna < 9; columna++)
            {
                if (asientos[fila, columna] == "Libre")
                {
                    asientos[fila, columna] = espectador.Nombre;
                    Console.WriteLine($"{espectador.Nombre} se sento en el asiento {fila + 1} {((char)('A' + columna))}.");
                    return true;
                }
            }
        }

        Console.WriteLine($"No hay asientos disponibles para {espectador.Nombre}.");
        return false;
    }

    public void MostrarAsientos()
    {
        Console.WriteLine("Estado de los asientos:");
        for (int i = 7; i >= 0; i--)
        {
            for (int j = 0; j < 9; j++)
            {
                Console.Write($"{asientos[i, j]} \t");
            }
            Console.WriteLine();
        }
    }
}

public class Program
{
    public static void Main()
    {
        Pelicula pelicula = new Pelicula("Avengers", 150, 13, "Joss Whedon");

        Cine cine = new Cine(pelicula, 10);

        Espectador espectador1 = new Espectador("Lola", 15, 12);
        Espectador espectador2 = new Espectador("Mei", 12, 5);
        Espectador espectador3 = new Espectador("Lolo", 16, 10);
        Espectador espectador4 = new Espectador("Jack", 18, 20);

        cine.MostrarAsientos();

        cine.SentarEspectador(espectador1);
        cine.SentarEspectador(espectador2);
        cine.SentarEspectador(espectador3);
        cine.SentarEspectador(espectador4);

        cine.MostrarAsientos();
    }
}

