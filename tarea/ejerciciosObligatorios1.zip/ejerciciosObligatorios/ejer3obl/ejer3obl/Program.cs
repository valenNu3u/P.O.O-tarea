﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Password
{
    private int longitud;
    private string contraseña;

    public Password()
    {
        longitud = 8;
        contraseña = GenerarPassword();
    }

    public Password(int longitud)
    {
        this.longitud = longitud;
        contraseña = GenerarPassword();
    }

    public int GetLongitud()
    {
        return longitud;
    }

    public void SetLongitud(int nuevaLongitud)
    {
        longitud = nuevaLongitud;
        contraseña = GenerarPassword();
    }

    public string GetContraseña()
    {
        return contraseña;
    }

    private string GenerarPassword()
    {
        string basePassword = "AAabcd123456";
        string nuevaContraseña = "";

        for (int i = 0; i < longitud; i++)
        {
            nuevaContraseña += basePassword[i % basePassword.Length];
        }

        return nuevaContraseña;
    }

    public bool EsFuerte()
    {
        int mayusculas = 0, minusculas = 0, numeros = 0;

        foreach (char c in contraseña)
        {
            if (c >= 'A' && c <= 'Z')
                mayusculas++;
            else if (c >= 'a' && c <= 'z')
                minusculas++;
            else if (c >= '0' && c <= '9')
                numeros++;
        }

        return mayusculas > 2 && minusculas > 1 && numeros > 5;
    }
}

class Program
{
    static void Main()
    {
        Console.Write("Ingrese la cantidad de contraseñas a generar: ");
        int cantidad = int.Parse(Console.ReadLine());

        Console.Write("Ingrese la longitud de las contraseñas: ");
        int longitud = int.Parse(Console.ReadLine());

        Password[] passwords = new Password[cantidad];
        bool[] esFuerteArray = new bool[cantidad];

        for (int i = 0; i < cantidad; i++)
        {
            passwords[i] = new Password(longitud);
            esFuerteArray[i] = passwords[i].EsFuerte();
        }

        Console.WriteLine("\nContraseñas:");
        for (int i = 0; i < cantidad; i++)
        {
            Console.WriteLine($"{passwords[i].GetContraseña()} - Fuerte: {esFuerteArray[i]}");
        }
        Console.ReadKey();
    }
}