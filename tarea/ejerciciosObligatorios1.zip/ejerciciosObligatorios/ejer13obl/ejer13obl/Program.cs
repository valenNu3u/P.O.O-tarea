﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer13obl
{
    public abstract class Empleado
    {
        protected string Nombre;
        protected int Edad;
        protected double Salario;
        protected const double PLUS = 300;

        public Empleado(string nombre, int edad, double salario)
        {
            Nombre = nombre;
            Edad = edad;
            Salario = salario;
        }

        public abstract void AplicarPlus(); 

        public void MostrarInfo()
        {
            Console.WriteLine($"Nombre: {Nombre}, Edad: {Edad}, Salario: {Salario}");
        }
    }

    class Comercial : Empleado
    {
        private double Comision;

        public Comercial(string nombre, int edad, double salario, double comision)
            : base(nombre, edad, salario)
        {
            Comision = comision;
        }

        public override void AplicarPlus()
        {
            if (Edad > 30 && Comision > 200)
            {
                Salario += PLUS;
            }
        }
    }

    class Repartidor : Empleado
    {
        private string Zona;

        public Repartidor(string nombre, int edad, double salario, string zona)
            : base(nombre, edad, salario)
        {
            Zona = zona;
        }

        public override void AplicarPlus()
        {
            if (Edad < 25 && Zona == "zona 3")
            {
                Salario += PLUS;
            }
        }
    }

    class Program
    {
        static void Main()
        {
            Comercial comercial1 = new Comercial("Juan", 35, 1200, 250);
            Repartidor repartidor1 = new Repartidor("Carlos", 22, 1000, "zona 3");

            Console.WriteLine("Antes de aplicar el PLUS:");
            comercial1.MostrarInfo();
            repartidor1.MostrarInfo();

            comercial1.AplicarPlus();
            repartidor1.AplicarPlus();

            Console.WriteLine("\nDespues de aplicar el PLUS:");
            comercial1.MostrarInfo();
            repartidor1.MostrarInfo();
            Console.ReadKey();
        }
    }
}