﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer4obl
{
    public class Electrodomestico
    {
        protected const double PRECIO_DEF = 100;
        protected const string COLOR_DEF = "blanco";
        protected const char CONSUMO_DEF = 'F';
        protected const double PESO_DEF = 5;

        protected double precioBase;
        protected string color;
        protected char consumoEnergetico;
        protected double peso;

        public double PrecioBase
        {
            get { return precioBase; }
            set { precioBase = value; }
        }

        public string Color
        {
            get { return color; }
            set { color = value; }
        }

        public char ConsumoEnergetico
        {
            get { return consumoEnergetico; }
            set { consumoEnergetico = value; }
        }

        public double Peso
        {
            get { return peso; }
            set { peso = value; }
        }

        public Electrodomestico()
        {
            precioBase = PRECIO_DEF;
            color = COLOR_DEF;
            consumoEnergetico = CONSUMO_DEF;
            peso = PESO_DEF;
        }

        public Electrodomestico(double precio, double peso)
        {
            precioBase = precio;
            color = COLOR_DEF;
            consumoEnergetico = CONSUMO_DEF;
            this.peso = peso;
        }

        public Electrodomestico(double precio, string color, char consumo, double peso)
        {
            precioBase = precio;
            this.color = ComprobarColor(color);
            this.consumoEnergetico = ComprobarConsumo(consumo);
            this.peso = peso;
        }

        private char ComprobarConsumo(char letra)
        {
            if (letra >= 'A' && letra <= 'F') return letra;
            return CONSUMO_DEF;
        }

        private string ComprobarColor(string color)
        {
            if (color == "blanco" || color == "negro" || color == "rojo" || color == "azul" || color == "gris")
            {
                return color;
            }
            return COLOR_DEF;
        }

        public virtual double PrecioFinal()
        {
            double precioFinal = precioBase;

            switch (consumoEnergetico)
            {
                case 'A': precioFinal += 100; break;
                case 'B': precioFinal += 80; break;
                case 'C': precioFinal += 60; break;
                case 'D': precioFinal += 50; break;
                case 'E': precioFinal += 30; break;
                case 'F': precioFinal += 10; break;
            }

            if (peso >= 0 && peso < 20) precioFinal += 10;
            else if (peso < 50) precioFinal += 50;
            else if (peso < 80) precioFinal += 80;
            else precioFinal += 100;

            return precioFinal;
        }
    }

    public class Lavadora : Electrodomestico
    {
        protected const double CARGA_DEF = 5;
        protected double carga;

        public double Carga
        {
            get { return carga; }
            set { carga = value; }
        }

        public Lavadora() : base()
        {
            carga = CARGA_DEF;
        }

        public Lavadora(double precio, double peso) : base(precio, peso)
        {
            carga = CARGA_DEF;
        }

        public Lavadora(double precio, string color, char consumo, double peso, double carga)
            : base(precio, color, consumo, peso)
        {
            this.carga = carga;
        }

        public override double PrecioFinal()
        {
            double precioFinal = base.PrecioFinal();
            if (carga > 30) precioFinal += 50;
            return precioFinal;
        }
    }

    public class Television : Electrodomestico
    {
        protected const int RESOLUCION_DEF = 20;
        protected const bool TDT_DEF = false;
        protected int resolucion;
        protected bool sintonizadorTDT;

        public int Resolucion
        {
            get { return resolucion; }
            set { resolucion = value; }
        }

        public bool SintonizadorTDT
        {
            get { return sintonizadorTDT; }
            set { sintonizadorTDT = value; }
        }

        public Television() : base()
        {
            resolucion = RESOLUCION_DEF;
            sintonizadorTDT = TDT_DEF;
        }

        public Television(double precio, double peso) : base(precio, peso)
        {
            resolucion = RESOLUCION_DEF;
            sintonizadorTDT = TDT_DEF;
        }

        public Television(double precio, string color, char consumo, double peso, int resolucion, bool tdt)
            : base(precio, color, consumo, peso)
        {
            this.resolucion = resolucion;
            this.sintonizadorTDT = tdt;
        }

        public override double PrecioFinal()
        {
            double precioFinal = base.PrecioFinal();
            if (resolucion > 40) precioFinal *= 1.3;
            if (sintonizadorTDT) precioFinal += 50;
            return precioFinal;
        }
    }

    class Program
    {
        static void Main()
        {
            Electrodomestico[] electrodomesticos = new Electrodomestico[10];

            electrodomesticos[0] = new Electrodomestico();
            electrodomesticos[1] = new Lavadora(200, "azul", 'B', 45, 35);
            electrodomesticos[2] = new Television(500, "negro", 'A', 60, 50, true);
            electrodomesticos[3] = new Lavadora(250, "gris", 'C', 30, 20);
            electrodomesticos[4] = new Television(400, "rojo", 'D', 25, 32, false);
            electrodomesticos[5] = new Electrodomestico(150, "blanco", 'E', 10);
            electrodomesticos[6] = new Lavadora(180, "negro", 'F', 55, 10);
            electrodomesticos[7] = new Television(300, "azul", 'B', 20, 42, true);
            electrodomesticos[8] = new Electrodomestico(120, "rojo", 'A', 15);
            electrodomesticos[9] = new Lavadora(220, "gris", 'C', 70, 50);

            double totalElectrodomesticos = 0, totalLavadoras = 0, totalTelevisiones = 0;

            foreach (Electrodomestico e in electrodomesticos)
            {
                double precio = e.PrecioFinal();
                totalElectrodomesticos += precio;

                if (e is Lavadora)
                    totalLavadoras += precio;
                else if (e is Television)
                    totalTelevisiones += precio;
            }

            Console.WriteLine($"Total de electrodomesticos: {totalElectrodomesticos}€");
            Console.WriteLine($"Total de lavadoras: {totalLavadoras}€");
            Console.WriteLine($"Total de televisiones: {totalTelevisiones}€");

            Console.ReadKey();
        }
    }
}

