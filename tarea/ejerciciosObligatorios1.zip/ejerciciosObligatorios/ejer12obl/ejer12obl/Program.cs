﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer12obl
{
    class Revolver
    {
        public int PosicionActual { get; set; }
        public int PosicionBala { get; set; }

        public Revolver()
        {
            PosicionActual = 1;
            PosicionBala = 3;
        }

        public bool Disparar()
        {
            return PosicionActual == PosicionBala;
        }

        public void SiguienteBala()
        {
            if (PosicionActual < 6)
            {
                PosicionActual++;
            }
            else
            {
                PosicionActual = 1;
            }
        }

        public void MostrarInfo()
        {
            Console.WriteLine($"Posicion actual: {PosicionActual}, Posicion de la bala: {PosicionBala}");
        }
    }

    class Jugador
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public bool Vivo { get; set; }

        public Jugador(int id)
        {
            Id = id;
            Nombre = "Jugador " + id;
            Vivo = true;
        }

        public void Disparar(Revolver r)
        {
            Console.WriteLine($"{Nombre} se apunta y aprieta el gatillo...");
            if (r.Disparar())
            {
                Console.WriteLine($"{Nombre} ha muerto. Fin del juego");
                Vivo = false;
            }
            else
            {
                Console.WriteLine($"{Nombre} sigue vivo.");
            }
            r.SiguienteBala();
        }
    }

    class Juego
    {
        public List<Jugador> Jugadores { get; set; }
        public Revolver Revolver { get; set; }

        public Juego(int cantidadJugadores)
        {
            if (cantidadJugadores < 1 || cantidadJugadores > 6)
            {
                cantidadJugadores = 6;
            }

            Jugadores = new List<Jugador>();
            for (int i = 1; i <= cantidadJugadores; i++)
            {
                Jugadores.Add(new Jugador(i));
            }

            Revolver = new Revolver();
        }

        public bool FinJuego()
        {
            foreach (var jugador in Jugadores)
            {
                if (!jugador.Vivo)
                {
                    return true;
                }
            }
            return false;
        }

        public void Ronda()
        {
            foreach (var jugador in Jugadores)
            {
                if (jugador.Vivo)
                {
                    jugador.Disparar(Revolver);
                    if (!jugador.Vivo)
                    {
                        break;
                    }
                }
            }
        }
    }

    class Program
    {
        static void Main()
        {
            Console.Write("Ingrese el numero de jugadores (1-6): ");
            int cantidadJugadores;
            if (!int.TryParse(Console.ReadLine(), out cantidadJugadores))
            {
                cantidadJugadores = 6;
            }

            Juego juego = new Juego(cantidadJugadores);
            Console.WriteLine("\nComienza el juego de la ruleta Rusa!!!\n");

            while (!juego.FinJuego())
            {
                juego.Ronda();
            }

            Console.WriteLine("\nEl juego termino");
        }
    }
}
